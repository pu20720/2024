import tkinter as tk
import subprocess  # 用於呼叫外部程式
from PIL import Image, ImageTk  # 需要先安裝 Pillow 套件：pip install Pillow

def start_ordering():
    """按下按鈕時啟動點餐程式"""
    try:
        # 啟動點餐程式 (ordering_system.py)
        subprocess.Popen(['python', '1017.py'])
    except Exception as e:
        print(f"無法啟動點餐系統: {e}")

# 建立 GUI 視窗
root = tk.Tk()
root.title("語音點餐系統")
root.geometry("800x600")

# 標題文字
label = tk.Label(root, text="歡迎使用語音點餐系統", font=("Arial", 16))
label.pack(pady=20)

# 載入背景圖片
background_image = Image.open("947coffee.jpg")  # 替換成你上傳的圖片檔名
background_photo = ImageTk.PhotoImage(background_image)

# 使用 Label 當作背景
background_label = tk.Label(root, image=background_photo)
background_label.place(x=0, y=0, relwidth=1, relheight=1)

# 開始點餐按鈕
start_button = tk.Button(root, text="開始點餐", font=("Arial", 14), command=start_ordering)
start_button.pack(pady=20)


# 啟動 GUI 事件循環
root.mainloop()

