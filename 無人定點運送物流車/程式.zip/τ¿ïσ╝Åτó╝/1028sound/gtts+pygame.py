from gtts import gTTS
import pygame
import io

def speak(text):
    mp3_fp = io.BytesIO()
    tts = gTTS(text=text, lang='zh-tw')
    tts.write_to_fp(mp3_fp)
    mp3_fp.seek(0)

    pygame.mixer.init()
    pygame.mixer.music.load(mp3_fp)
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        continue

speak("你好，歡迎使用語音助手")
