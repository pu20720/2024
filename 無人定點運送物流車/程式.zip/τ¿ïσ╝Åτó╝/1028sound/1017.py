import os
import speech_recognition as sr
import openai
import pandas as pd
import re
import sys
import json
from datetime import datetime
import gspread
from contextlib import contextmanager
from ctypes import CFUNCTYPE, c_char_p, c_int, cdll
from gtts import gTTS  # 用於文字轉語音
import pygame  # 用於播放音頻

# 設置 ALSA 錯誤處理，忽略警告
ERROR_HANDLER_FUNC = CFUNCTYPE(None, c_char_p, c_int, c_char_p, c_int, c_char_p)

def py_error_handler(filename, line, function, err, fmt):
    pass

c_error_handler = ERROR_HANDLER_FUNC(py_error_handler)

@contextmanager
def noalsaerr():
    asound = cdll.LoadLibrary('libasound.so')
    asound.snd_lib_error_set_handler(c_error_handler)
    yield
    asound.snd_lib_error_set_handler(None)

# 初始化 pygame
pygame.mixer.init()

# gTTS 文字轉語音並播放
def speak_text(text):
    try:
        tts = gTTS(text=text, lang='zh-tw')  # 生成語音文件
        audio_file = "temp_audio.mp3"
        tts.save(audio_file)  # 保存音頻
        
        # 播放音頻
        pygame.mixer.music.load(audio_file)
        pygame.mixer.music.play()
        
        # 等待播放結束
        while pygame.mixer.music.get_busy():
            continue

        os.remove(audio_file)  # 播放完成後刪除音頻文件
    except Exception as e:
        print(f"播放音頻時出現錯誤: {e}")

# 讀取 CSV 資料
def load_csv(filepath='coffee2.csv', encoding='big5'):
    try:
        data = pd.read_csv(filepath, encoding=encoding)
        print("CSV 加載成功。")
        return data
    except Exception as e:
        print(f"無法加載 CSV：{e}")
        exit()

# 設置 OpenAI API 金鑰
def set_openai_api_key():
    api_key = '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'
    if not api_key:
        print("請設置 OPENAI_API_KEY 環境變數。")
        exit()
    openai.api_key = api_key

cart = []  # 初始化購物車

# 添加到購物車
def add_to_cart(item_name, quantity, data):
    global cart
    item = data[data['品項'] == item_name]
    if not item.empty:
        for _ in range(quantity):
            cart.append({"品項": item.iloc[0]['品項'], "價格": item.iloc[0]['價格']})
        return f"已將 {quantity} 杯 {item_name} 加入購物車。"
    else:
        return f"菜單中找不到品項 {item_name}。"

# 將中文數字轉為阿拉伯數字
def chinese_to_number(chinese):
    chinese_numerals = {'一': 1, '二': 2,'兩': 2, '三': 3, '四': 4, '五': 5, 
                        '六': 6, '七': 7, '八': 8, '九': 9, '十': 10}
    return chinese_numerals.get(chinese, 0)

# 提取品項名稱和數量
def extract_item_name(response):
    matches = re.findall(r'(\d+|[一二兩三四五六七八九十])\s*(杯|片|份|個)\s*([\w\s]+)', response)
    items = []
    for match in matches:
        quantity = int(match[0]) if match[0].isdigit() else chinese_to_number(match[0])
        item_name = match[2].strip()
        items.append((item_name, quantity))
    return items

# 移除購物車品項
def remove_from_cart(item_name, quantity=1):
    global cart
    
    item_count = sum(1 for item in cart if item['品項'] == item_name)
    if item_count == 0:
        response = f"購物車中沒有找到 {item_name}。"
        print(response)
        speak_text(response)
        return response
    
    remove_count = min(quantity, item_count)
    new_cart = []
    removed_items = 0
    
    for item in cart:
        if item['品項'] == item_name and removed_items < remove_count:
            removed_items += 1
        else:
            new_cart.append(item)
    
    cart[:] = new_cart  # 更新購物車
    
    response = f"已從購物車中移除 {removed_items} 個 {item_name}。" if removed_items > 0 else f"購物車中沒有找到 {item_name}。"
    print(response)
    speak_text(response)
    return response

# 顯示目前購物車
def display_cart(cart):
    if not cart:
        print("您的購物車是空的。")
    else:
        cart_summary = {}
        for item in cart:
            item_name = item['品項']
            if item_name in cart_summary:
                cart_summary[item_name]['數量'] += 1
            else:
                cart_summary[item_name] = {
                    '價格': item['價格'],
                    '數量': 1
                }

        cart_display = "當前購物車:"
        for item_name, details in cart_summary.items():
            cart_display += (f"品項: {item_name} 價格: {details['價格']} 數量: {details['數量']}")
            response = cart_display
    print(response)
    speak_text(response)
    return cart_display
# 生成訂單編號
def generate_order_id():
    return datetime.now().strftime('%Y%m%d%H%M%S')

# 確認訂單並詢問桌號
def confirm_order():
    response = "請提供您的桌號。"
    print(response)
    speak_text(response)

    # 接收桌號語音輸入
    table_number = speech_to_text()
    
    # 檢查桌號是否輸入成功
    if table_number:
        response = f"已記錄桌號為 {table_number}"
        print(response)
        speak_text(response)
        
        # 上傳訂單，將桌號傳入
        update_existing_sheet(cart, table_number)
        
        # 清空購物車
        cart.clear()
    else:
        response = "無法識別桌號，請重試。"
        print(response)
        speak_text(response)



# 更新雲端資料函數，加入桌號參數
def update_existing_sheet(cart, table_number):
    try:
        gc = gspread.service_account(filename='token.json')
        sh = gc.open_by_url('https://docs.google.com/spreadsheets/d/1YPzvvQrQurqlZw2joMaDvDse-tCY9YX-7B2fzpc9qYY/edit?usp=sharing')
        worksheet = sh.get_worksheet(1)

        # 整理訂單資料
        cart_summary = {}
        for item in cart:
            if item['品項'] in cart_summary:
                cart_summary[item['品項']]['數量'] += 1
            else:
                cart_summary[item['品項']] = {'價格': item['價格'], '數量': 1}

        # 整理餐點內容為字符串
        cart_items_str = ', '.join([f"{item_name} x{details['數量']}" for item_name, details in cart_summary.items()])

        # 訂單的額外資訊
        timestamp = datetime.now().strftime('%Y/%m/%d %H:%M:%S')  # 訂單時間
        name = ""
        phone = ""
        payment_method = "Line Pay"  # 付款方式
        total_price = int(sum(int(item['價格']) * details['數量'] for item_name, details in cart_summary.items())) 
        note = ""  # 備註

        # 按照指定格式準備資料
        order_data = [
            [timestamp,table_number, name, phone, payment_method, cart_items_str, total_price, note]
        ]

        # 將訂單資料追加到表格的末尾
        worksheet.append_rows(order_data)
        # 清空購物車
        cart.clear()
        return {"message": "訂單已確認並更新到 Google Sheets。"}

    except Exception as e:
        print(f"Error in confirm_order: {e}")
        return {"message": "上傳訂單失敗，請稍後再試。"}



# 語音識別
def speech_to_text():
    with noalsaerr():
        recognizer = sr.Recognizer()
        with sr.Microphone() as source:
            print("請說話...")
            recognizer.adjust_for_ambient_noise(source)  # 調整麥克風雜訊
            audio = recognizer.listen(source)  # 聆聽用戶語音
            
            try:
                msg = recognizer.recognize_google(audio, language="zh-TW")  # 語音轉文字
                print(f"語音輸入: {msg}")  # 查看語音轉文字結果
                return msg
            except sr.UnknownValueError:
                print("無法理解語音。")
            except sr.RequestError as e:
                print(f"語音服務錯誤：{e}")
    return None  # 如果失敗則返回 None


# 主循環
def main():
    data = load_csv()
    set_openai_api_key()
    
    while True: 
        print("\n請講出您的指令（說 '退出' 以結束程式）：")
        # 語音輸入
        msg = speech_to_text()

            # 如果無法理解語音或語音轉文字失敗，跳過本次循環
        if msg is None:
            continue  # 繼續到下一次迴圈，等待新的語音輸入

        if msg.lower() == '退出':
            response = "程式已退出。"
            print(response)
            speak_text(response)
            break

        elif '查看購物車' in msg or '購物車' in msg or '查看購物' in msg : 
            display_cart(cart)
            continue

        elif '移除' in msg or '刪除' in msg or '拿掉' in msg:
            items = extract_item_name(msg)
            if items:
                for item_name, quantity in items:
                    remove_response = remove_from_cart(item_name, quantity)
                    print(remove_response)
            else:
                response = "無法從指令中提取要移除的品項名稱。"
                print(response)
                speak_text(response)
            continue
        
        elif '確認訂單' in msg or 'confirm order' in msg:
            if not cart:
                response = "購物車是空的，無法確認訂單。"
                print(response)
                speak_text(response)
                continue
            confirm_order()
            response = "結帳中 請稍後  確認付款 訂單已上傳"
            print(response)
            speak_text(response)
            update_existing_sheet(cart)  # 將 cart 傳入
            cart.clear()

        
        
        # 使用 OpenAI 的 ChatGPT 來回應
        # 準備菜單資料供 ChatGPT 參考
        info_from_csv = data[['種類', '品項', '價格', '標籤']]
        info_str = f"Category: {info_from_csv['種類'].tolist()}, Item: {info_from_csv['品項'].tolist()}, Price: {info_from_csv['價格'].tolist()}, Tag: {info_from_csv['標籤'].tolist()}"
        
        try:
            completion = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "你是一個線上咖啡廳點餐助手，請以簡潔的方式回覆用戶。"},
                    {"role": "system", "content": "請根據以下資料回答問題: " + info_str},
                    {"role": "system", "content": "當客人說到刪除或移除字眼時，請務必回復刪除多少數量加品項，例如：'好的，已刪除一杯美式' "},
                    {"role": "system", "content": "當客人點餐時，請務必回復品項和數量，例如：'好的，你點的是一杯美式，價格是50元。請問還有需要為您服務嗎？' 或 '好的，您要一杯榛果拿鐵，價格為80元。請問還有其他需要幫忙的嗎？'"},
                    {"role": "user", "content": msg},
                ],
                max_tokens = 70
            )
            
            response = completion.choices[0].message['content']
            print(f"回應: {response}")
            speak_text(response)
            
            # 從回應中提取多個品項名稱和數量並加入購物車
            items = extract_item_name(response)
            if items:
                for item_name, quantity in items:  # 遍歷每個提取的品項和數量
                    add_response = add_to_cart(item_name, quantity, data)  # 將每個品項加入購物車
                    print(add_response)
                    speak_text(add_response)
            else:
                response = "無法從回應中提取品項名稱。"
                print(response)

        
        except Exception as e:
            response = f"與 OpenAI 通訊時發生錯誤: {e}"
            print(response)
            speak_text("與 OpenAI 通訊時發生錯誤。")

if __name__ == "__main__":
    main()