using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class selectmanager : MonoBehaviour
{
    // 連結到 Mode1 的按鈕
    public void GOToGame1()
    {
        SceneManager.LoadScene("Mode1");
    }

    // 連結到 Mode2 的按鈕
    public void GOToGame2()
    {
        SceneManager.LoadScene("MODE2");
    }

    // 連結到 Mode3 的按鈕
    public void GOToGame3()
    {
        SceneManager.LoadScene("MODE3");
    }
}
