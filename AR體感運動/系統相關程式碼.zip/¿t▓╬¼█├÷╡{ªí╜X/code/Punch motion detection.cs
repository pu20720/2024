using UnityEngine;
using Windows.Kinect;
using System.Collections.Generic;

public class GestureDetector : MonoBehaviour
{
    private KinectSensor sensor; // Kinect傳感器
    private BodyFrameReader bodyFrameReader; // 身體框架讀取器
    private Body[] bodies;  // 用來存儲身體數據的陣列

    public delegate void GestureDetectedHandler(int gestureCode); // 定義手勢偵測
    public event GestureDetectedHandler OnGestureDetected; // 手勢偵測事件

    private Vector3 previousRightHandPos;  // 上一幀右手位置
    private Vector3 previousLeftHandPos;  // 上一幀左手位置

    private List<Vector3> rightHandHistory = new List<Vector3>();  // 存儲右手位置歷史數據
    private List<Vector3> leftHandHistory = new List<Vector3>();  // 存儲左手位置歷史數據

    private float basePunchSpeedThreshold = 3.0f; // 揮拳速度閾值 (秒)
    private float basePunchDistanceThreshold = 0.25f; // 揮拳距離閾值 (historySize/fps = 10/30 = 約 0.33 秒)
    private float cooldownTime = 1.5f;  // 左右拳冷卻時間

    private float lastRightPunchTime = -1.0f; // 上次右拳動作的時間
    private float lastLeftPunchTime = -1.0f; // 上次左拳動作的時間

    private float defenseThreshold = 0.25f; // 左右手與頭部的距離
    private float handDistanceThreshold = 0.15f; // 雙手距離閾值
    private int historySize = 10; // 歷史數據大小

    private Vector3 previousShoulderPos; // 上一幀的肩部位置
    private float backwardDistanceThreshold = 0.02f; // 後退距離閾值（單位公尺）
    private float backwardCooldown = 2.0f; // 向後移動的冷卻時間
    private float lastBackwardMoveTime = -1.0f; // 上次向後移動的時間

    private float defenseCooldownTime = 2f;  // 防禦冷卻時間
    private float lastDefenseTime = -1.0f;  // 上次偵測防禦的時間

    public float defenseCooldownDuration = 1.0f; // 防禦後不計分時間
    public float backwardCooldownDuration = 1.0f; // 後退後不計分時間
    
    private bool isInDefenseMode = false; // 是否處於防禦模式
    private bool isInBackwardMode = false; // 是否處於後退模式

    // 當防禦或後退禁用時觸發
    public delegate void DefenseModeHandler(bool isActive); // 定義防禦模式的委託
    public event DefenseModeHandler OnDefenseModeChanged; // 防禦模式變化事件

    public delegate void BackwardModeHandler(bool isActive); // 定義後退模式的委託
    public event BackwardModeHandler OnBackwardModeChanged; // 後退模式變化事件
    
    void Start()
    {
        sensor = KinectSensor.GetDefault(); // 獲取默認的Kinect傳感器
        if (sensor != null)
        {
            bodyFrameReader = sensor.BodyFrameSource.OpenReader(); // 開啟身體框架讀取器
            if (!sensor.IsOpen)
            {
                sensor.Open(); // 打開傳感器
            }
        }
        previousShoulderPos = Vector3.zero; // 初始化脊椎肩部的位置
    }

    void Update()
    {
        if (bodyFrameReader != null)
        {
            var frame = bodyFrameReader.AcquireLatestFrame(); // 獲取最新的身體框架
            if (frame != null)
            {
                if (bodies == null)
                {
                    bodies = new Body[sensor.BodyFrameSource.BodyCount]; // 初始化身體數據
                }

                frame.GetAndRefreshBodyData(bodies); // 獲取並刷新身體數據
                foreach (var body in bodies)
                {
                    if (body != null && body.IsTracked) // 確保身體數據有效且被追蹤
                    {
                        DetectDefense(body); // 偵測防禦動作
                        DetectRightPunch(body); // 偵測右手揮拳動作
                        DetectLeftPunch(body); // 偵測左手揮拳動作
                        DetectBackwardMove(body); // 偵測向後移動動作
                    }
                }

                frame.Dispose(); // 釋放框架資源
                frame = null;
            }
        }
    }

    private void DetectDefense(Body body)
    {
        var leftHand = body.Joints[JointType.HandLeft].Position; // 獲取左手位置
        var rightHand = body.Joints[JointType.HandRight].Position; // 獲取右手位置
        var head = body.Joints[JointType.Head].Position; // 獲取頭部位置

        // 計算左手和右手與頭部的距離
        float leftHandToHead = Vector3.Distance(new Vector3(leftHand.X, leftHand.Y, leftHand.Z), new Vector3(head.X, head.Y, head.Z));
        float rightHandToHead = Vector3.Distance(new Vector3(rightHand.X, rightHand.Y, rightHand.Z), new Vector3(head.X, head.Y, head.Z));
        float handsDistance = Vector3.Distance(new Vector3(leftHand.X, leftHand.Y, leftHand.Z), new Vector3(rightHand.X, rightHand.Y, rightHand.Z));

        // 是否處於防禦狀態
        if (leftHandToHead < defenseThreshold && rightHandToHead < defenseThreshold && handsDistance < handDistanceThreshold)
        {
            float currentTime = Time.time; // 獲取當前時間
            if (currentTime - lastDefenseTime >= defenseCooldownTime) // 檢查防禦冷卻
            {
                Debug.Log("防禦狀態"); // 記錄防禦狀態
                TriggerAnimation("Defense"); // 觸發防禦動畫
                OnGestureDetected?.Invoke(3); // 發出防禦訊號

                // 啟用防禦不計分
                if (!isInDefenseMode)
                {
                    isInDefenseMode = true; // 設置防禦模式為啟用
                    OnDefenseModeChanged?.Invoke(true); // 啟用防禦不計分
                    Invoke("ResetDefenseMode", defenseCooldownDuration); // 1秒後關閉防禦不計分
                }

                lastDefenseTime = currentTime; // 更新上次偵測防禦的時間
            }
        }
    }

    private void DetectRightPunch(Body body)
    {
        var rightHand = body.Joints[JointType.HandRight].Position; // 獲取右手位置
        Vector3 rightHandPos = new Vector3(rightHand.X, rightHand.Y, rightHand.Z);
		
		// 添加當前幀手部位置到歷史數據中
        if (rightHandHistory.Count >= historySize)
        {
            rightHandHistory.RemoveAt(0); // 如果歷史數據超過大小限制，移除最舊數據
        }
        rightHandHistory.Add(rightHandPos); // 添加當前手部位置到歷史數據
		
		// 計算手部的平滑速度
        float speed = CalculateSmoothedSpeed(rightHandHistory); // 計算平滑速度
        float distanceMoved = CalculateDistanceMoved(rightHandHistory); // 計算移動距離
		
		// 自適應閾值
        float punchSpeedThreshold = AdjustThreshold(basePunchSpeedThreshold, speed); // 調整揮拳速度閾值
        float punchDistanceThreshold = AdjustThreshold(basePunchDistanceThreshold, distanceMoved); // 調整揮拳距離閾值

        // 檢查是否達到揮拳條件
        if (speed > punchSpeedThreshold && distanceMoved > punchDistanceThreshold)
        {
            float currentTime = Time.time; // 獲取當前時間
            if (currentTime - lastRightPunchTime >= cooldownTime) // 檢查冷卻時間
            {
                Debug.Log("檢測到右手揮拳動作！"); // 記錄右手揮拳動作
                TriggerAnimation("PunchR"); // 觸發右手揮拳動畫
                OnGestureDetected?.Invoke(1); // 發出右手揮拳訊號
                lastRightPunchTime = currentTime; // 更新上次右拳動作的時間
            }
        }

		// 更新上一幀的手部位置
        previousRightHandPos = rightHandPos; 
    }

    private void DetectLeftPunch(Body body)
    {
        var leftHand = body.Joints[JointType.HandLeft].Position; // 獲取左手位置
        Vector3 leftHandPos = new Vector3(leftHand.X, leftHand.Y, leftHand.Z);
		
		// 添加當前幀手部位置到歷史數據中
        if (leftHandHistory.Count >= historySize)
        {
            leftHandHistory.RemoveAt(0); // 如果歷史數據超過大小限制，移除最舊數據
        }
        leftHandHistory.Add(leftHandPos); // 添加當前手部位置到歷史數據
		
		// 計算手部的平滑速度
        float speed = CalculateSmoothedSpeed(leftHandHistory); // 計算平滑速度
        float distanceMoved = CalculateDistanceMoved(leftHandHistory); // 計算移動距離
		
		// 自適應閾值
        float punchSpeedThreshold = AdjustThreshold(basePunchSpeedThreshold, speed); // 調整揮拳速度閾值
        float punchDistanceThreshold = AdjustThreshold(basePunchDistanceThreshold, distanceMoved); // 調整揮拳距離閾值

        // 檢查是否達到揮拳條件
        if (speed > punchSpeedThreshold && distanceMoved > punchDistanceThreshold)
        {
            float currentTime = Time.time; // 獲取當前時間
            if (currentTime - lastLeftPunchTime >= cooldownTime) // 檢查冷卻時間
            {
                Debug.Log("檢測到左手揮拳動作！"); // 記錄左手揮拳動作
                TriggerAnimation("PunchL"); // 觸發左手揮拳動畫
                OnGestureDetected?.Invoke(2); // 發出左手揮拳訊號
                lastLeftPunchTime = currentTime; // 更新上次左拳動作的時間
            }
        }

        previousLeftHandPos = leftHandPos; // 更新上一幀的手部位置
    }
    
    private void DetectBackwardMove(Body body)
    {
        var spineShoulder = body.Joints[JointType.SpineShoulder].Position; // 獲取脊椎肩部位置
        Vector3 currentShoulderPos = new Vector3(spineShoulder.X, spineShoulder.Y, spineShoulder.Z); // 轉換為Vector3格式

        // 計算移動距離
        float distanceMoved = (currentShoulderPos - previousShoulderPos).magnitude; // 計算肩部的移動距離

        // 判斷是否滿足後退的條件
        if (distanceMoved > backwardDistanceThreshold) // 使用距離閾值判斷後退
        {
            float currentTime = Time.time; // 獲取當前時間
            if (currentTime - lastBackwardMoveTime >= backwardCooldown) // 檢查冷卻時間
            {
                Debug.Log("檢測到身體向後移動！"); // 記錄向後移動動作
                TriggerAnimation("Backward");  // 執行後退動作
                OnGestureDetected?.Invoke(4); // 傳遞後退訊號
                lastBackwardMoveTime = currentTime; // 更新上次向後移動的時間

                // 啟用後退不計分
                if (!isInBackwardMode)
                {
                    isInBackwardMode = true; // 設置後退模式為啟用
                    OnBackwardModeChanged?.Invoke(true); // 啟用後退不計分
                    Invoke("ResetBackwardMode", backwardCooldownDuration); // 1秒後關閉啟用後退不計分
                }
            }
        }

        previousShoulderPos = currentShoulderPos; // 更新上一幀的肩部位置
    }

    private float CalculateSmoothedSpeed(List<Vector3> handHistory)
    {
        if (handHistory.Count < 2) return 0f; // 如果歷史數據不足，返回0

        float smoothedSpeed = 0f; // 平滑速度初始化
        float alpha = 0.1f;  // 平滑因子
        Vector3 prevPos = handHistory[0]; // 上一位置
        
        foreach (var pos in handHistory)
        {
            float speed = (pos - prevPos).magnitude / Time.deltaTime; // 計算當前幀的速度
            smoothedSpeed = alpha * speed + (1 - alpha) * smoothedSpeed; // 使用指數移動平均來平滑速度
            prevPos = pos; // 更新上一位置
        }

        return smoothedSpeed; // 返回平滑速度
    }

    private float CalculateDistanceMoved(List<Vector3> handHistory)
    {
        if (handHistory.Count < 2) return 0f; // 如果歷史數據不足，返回0

        float initialZ = handHistory[0].z; // 初始位置的Z坐標
        float finalZ = handHistory[handHistory.Count - 1].z; // 最終位置的Z坐標

        return Mathf.Abs(finalZ - initialZ); // 返回Z坐標的移動距離
    }

    private float AdjustThreshold(float baseThreshold, float actualValue)
    {	
        // 根據實際值調整閾值
        return baseThreshold + (actualValue * 0.1f); // 調整閾值為基礎閾值加上實際值的10%
    }

    private void TriggerAnimation(string action)
    {
        Animator animator = GetComponent<Animator>(); // 獲取動畫控制器
        if (animator != null)
        {
            animator.SetTrigger(action); // 設置觸發器以啟動動畫
        }
    }

    // 重置防禦不計分
    private void ResetDefenseMode()
    {
        isInDefenseMode = false; // 將防禦模式設置為禁用
        OnDefenseModeChanged?.Invoke(false); // 關閉防禦不計分
    }

    // 重置後退不計分
    private void ResetBackwardMode()
    {
        isInBackwardMode = false; // 將後退模式設置為禁用
        OnBackwardModeChanged?.Invoke(false); // 關閉後退不計分
    }

    void OnApplicationQuit()
    {
        if (bodyFrameReader != null)
        {
            bodyFrameReader.Dispose(); // 釋放身體框架讀取器
            bodyFrameReader = null;
        }

        if (sensor != null)
        {
            if (sensor.IsOpen)
            {
                sensor.Close(); // 關閉傳感器
            }

            sensor = null;
        }
    }
}
