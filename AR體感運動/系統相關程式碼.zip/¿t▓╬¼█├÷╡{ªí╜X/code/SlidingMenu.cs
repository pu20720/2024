using UnityEngine;
using UnityEngine.UI;

public class SlidingMenu : MonoBehaviour
{
    public RectTransform menuPanel; // 菜單Panel
    public float slideSpeed = 10f;  // 滑動速度
    public bool isOpen = false;     // 菜單是否打開

    private Vector2 closedPosition; // 菜單關閉時的位置
    private Vector2 openPosition;   // 菜單打開時的位置

    void Start()
    {
        // 設置菜單的打開和關閉位置
        closedPosition = menuPanel.anchoredPosition;
        openPosition = new Vector2(0, menuPanel.anchoredPosition.y);
    }

    void Update()
    {
        // 根據菜單狀態平滑移動菜單
        if (isOpen)
        {
            menuPanel.anchoredPosition = Vector2.Lerp(menuPanel.anchoredPosition, openPosition, Time.deltaTime * slideSpeed);
        }
        else
        {
            menuPanel.anchoredPosition = Vector2.Lerp(menuPanel.anchoredPosition, closedPosition, Time.deltaTime * slideSpeed);
        }
    }

    // 切換菜單狀態
    public void ToggleMenu()
    {
        isOpen = !isOpen;
    }
}
