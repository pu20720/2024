using UnityEngine;
using UnityEngine.UI;
using System.IO;
using SFB;


public class UpImage : MonoBehaviour
{
    public Image displayImage; // 用於顯示的 UI Image
    public Button uploadButton; // 上傳按鈕

    void Start()
    {
        uploadButton.onClick.AddListener(OnUploadButtonClick);
    }

    void OnUploadButtonClick()
    {
        string path = OpenFileDialog(); // 打開選擇文件的對話框
        if (!string.IsNullOrEmpty(path))
        {
            LoadImage(path); // 加載並顯示圖片
        }
    }

    string OpenFileDialog()
    {
        string defaultPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments);
        string[] paths = StandaloneFileBrowser.OpenFilePanel("Select Image", defaultPath, "*", false);
        return paths.Length > 0 ? paths[0] : null;
    }


    void LoadImage(string filePath)
    {
        if (string.IsNullOrEmpty(filePath))
        {
            Debug.LogError("File path is null or empty!");
            return;
        }

        Debug.Log("Attempting to load file: " + filePath);
        if (!File.Exists(filePath))
        {
            Debug.LogError("File not found at path: " + filePath);
            return;
        }

        byte[] imageBytes = File.ReadAllBytes(filePath);
        Texture2D texture = new Texture2D(2, 2);
        texture.LoadImage(imageBytes);

        Sprite sprite = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2(0.5f, 0.5f));
        displayImage.sprite = sprite;
    }

}
