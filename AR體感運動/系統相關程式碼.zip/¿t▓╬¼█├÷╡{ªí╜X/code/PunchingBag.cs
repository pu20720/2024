using UnityEngine;

public class PunchingBag : MonoBehaviour
{
    public float hitForce = 10f; // 打擊力
    private Rigidbody rb; // 剛體引用
    public TutorialManager tutorialManager; // 引用TutorialManager腳本
    private Animator animator;
    void Start()
    {
        rb = GetComponent<Rigidbody>(); // 獲取剛體組件
        animator = GetComponent<Animator>();
    }

    public void PlayDefense()
    {
        animator.SetTrigger("Defense");
    }

    public void PlayIdle()
    {
        animator.Play("Idle");
    }

    // 當碰撞發生時調用
    void OnCollisionEnter(Collision collision)
    {
        // 只檢測自己（PunchingBag）的部位，而不是對方
        DetectHitPart(collision.contacts[0].thisCollider); // thisCollider是自己被碰到的部位
    }

    void ApplyForceToBag(Vector3 direction)
    {
        rb.AddForce(direction * hitForce, ForceMode.Impulse); // 根據方向和力對沙袋施加衝擊力
    }

    void DetectHitPart(Collider hitCollider)
    {
        // 檢測碰撞到沙袋的哪個部位
        if (hitCollider.CompareTag("Head")) // 如果碰撞到的部分是頭部
        {
            tutorialManager.RegisterHit("Head"); // 通知TutorialManager擊中了頭部
        }
        else if (hitCollider.CompareTag("Body")) // 如果碰撞到的部分是身體
        {
            tutorialManager.RegisterHit("Body"); // 通知TutorialManager擊中了身體
        }
        else if (hitCollider.CompareTag("Hand")) // 如果碰撞到的部分是手部
        {
            tutorialManager.RegisterHit("Hand"); // 通知TutorialManager擊中了手部
        }
    }
}
