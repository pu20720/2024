using UnityEngine; 
using TMPro;
using UnityEngine.SceneManagement;
using System.Collections;

public class ScoringSystem : MonoBehaviour
{
    public GameObject player;  // 玩家物件
    public GameObject opponent; // 對手物件
    public TextMeshProUGUI playerScoreText; // 玩家分數顯示
    public TextMeshProUGUI opponentScoreText; // 對手分數顯示
    public TextMeshProUGUI resultText; // 結果顯示
    public TextMeshProUGUI timerText; // 倒數計時顯示
    public TextMeshProUGUI countdownText; // 遊戲開始倒數計時
    public GameObject startCountdownPanel; // 遊戲開始倒數計時面板
    public GameObject endGamePanel; // 結束視窗
    public float gameDuration = 30f; // 遊戲時長
    public float startDelay = 5f; // 開始前倒數時間
    private float timer;
    private bool gameEnded = false; // 用於追蹤遊戲是否結束
    private bool gameStarted = false; // 用於追蹤遊戲是否開始

    private int playerScore = 0; // 玩家分數
    private int opponentScore = 0; // 對手分數
    public GameObject panel1; // 第一個計分面板
    public GameObject panel2; // 第二個計分面板
    public GameObject tpanel; // 時間面板

    void Start()
    {
        timer = gameDuration;
        playerScoreText.text = "玩家分數: 0";
        opponentScoreText.text = "對手分數: 0";
        resultText.text = "";
        endGamePanel.SetActive(false); // 確保結束畫面一開始是隱藏的
        panel1.SetActive(false);
        panel2.SetActive(false);
        tpanel.SetActive(false);
        Time.timeScale = 0; // 暫停背景動作
        StartCoroutine(StartGameCountdown()); // 開始倒數計時
    }

    void Update()
    {
        // 如果遊戲已結束，等待玩家點擊以重新開始
        if (gameEnded && Input.GetMouseButtonDown(0))
        {
            Time.timeScale = 1; // 恢復遊戲時間
            SceneManager.LoadScene(SceneManager.GetActiveScene().name); // 重新加載場景
        }
    }

    private IEnumerator StartGameCountdown()
    {
        float countdownTimer = startDelay; // 設置倒數時間
        while (countdownTimer > 0)
        {
            countdownText.text = "開始前倒數: " + Mathf.Ceil(countdownTimer).ToString();
            yield return new WaitForSecondsRealtime(1f);
            countdownTimer--;
        }

        countdownText.text = "Go!";
        yield return new WaitForSecondsRealtime(1f); // 確保延遲 1 秒顯示 "Go!"

        startCountdownPanel.SetActive(false); // 隱藏倒數面板
        gameStarted = true; // 遊戲開始
        Time.timeScale = 1; // 恢復遊戲
        StartCoroutine(GameTimer()); // 開始倒數計時
        panel1.SetActive(true);
        panel2.SetActive(true);
        tpanel.SetActive(true);
    }

    private IEnumerator GameTimer()
    {
        while (timer > 0 && gameStarted)
        {
            UpdateTimerText(); // 更新計時顯示
            yield return new WaitForSeconds(1f); // 等待1秒
            timer--; // 減少剩餘時間
        }

        if (gameStarted)
        {
            EndGame(); // 遊戲結束
        }
    }

    private void UpdateTimerText()
    {
        timerText.text = "剩餘時間: " + Mathf.Ceil(timer).ToString() + "s"; // 更新倒數計時顯示
    }

    private void EndGame()
    {
        gameEnded = true; // 設置遊戲結束標誌
        gameStarted = false; // 停止遊戲狀態
        panel1.SetActive(false); // 隱藏第一個計分面板
        panel2.SetActive(false); // 隱藏第二個計分面板
        tpanel.SetActive(false);
        endGamePanel.SetActive(true); // 顯示結束畫面
        Time.timeScale = 0; // 暫停遊戲

        // 根據分數顯示結果
        if (playerScore > opponentScore)
        {
            resultText.text = "你贏了!";
        }
        else if (playerScore < opponentScore)
        {
            resultText.text = "你輸了!";
        }
        else
        {
            resultText.text = "平手!";
        }
    }

    public void AddPlayerScore(int points)
    {
        playerScore += points; // 增加指定的分數
        playerScoreText.text = "玩家分數: " + playerScore;
    }

    public void AddOpponentScore(int points)
    {
        opponentScore += points; // 增加指定的分數
        opponentScoreText.text = "對手分數: " + opponentScore;
    }
    // 確保退出時正確釋放資源，恢復時間
    private void OnApplicationQuit()
    {
        Time.timeScale = 1; // 恢復遊戲時間
    }
}