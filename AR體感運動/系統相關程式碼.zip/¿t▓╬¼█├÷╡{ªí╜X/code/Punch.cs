using UnityEngine;
using Windows.Kinect;
using System.Collections.Generic;

public class Punch : MonoBehaviour
{
    public float hitForce = 10f; // 撞擊的力量
    private Rigidbody rb;

    // Kinect 相關變數
    private KinectSensor kinectSensor;
    private BodyFrameReader bodyFrameReader;
    private Body[] bodies = null;

    // 拳擊偵測參數
    private Vector3 previousRightHandPos;
    private Vector3 previousLeftHandPos;
    private List<Vector3> rightHandHistory = new List<Vector3>();
    private List<Vector3> leftHandHistory = new List<Vector3>();

    private float basePunchSpeedThreshold = 2.5f;
    private float basePunchDistanceThreshold = 0.25f;
    private float cooldownTime = 0.8f;

    private float lastRightPunchTime = -1.0f;
    private float lastLeftPunchTime = -1.0f;
    private int historySize = 10;

    // 螢幕震動
    private Camera mainCamera;
    private Vector3 originalCameraPosition;
    private bool isShaking = false;
    public float shakeDuration = 0.2f;
    public float shakeMagnitude = 0.1f;

    // 反饋管理
    public Feedback feedback; // 用來管理反饋的組件

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        InitializeKinect();
        mainCamera = Camera.main;
        if (mainCamera != null)
        {
            originalCameraPosition = mainCamera.transform.position;
        }
    }

    void InitializeKinect()
    {
        kinectSensor = KinectSensor.GetDefault();

        if (kinectSensor != null)
        {
            bodyFrameReader = kinectSensor.BodyFrameSource.OpenReader();
            if (!kinectSensor.IsOpen)
            {
                kinectSensor.Open();
            }

            bodies = new Body[kinectSensor.BodyFrameSource.BodyCount];
            Debug.Log("Kinect Sensor Initialized.");
        }
        else
        {
            Debug.LogError("Kinect Sensor not found.");
        }
    }

    void Update()
    {
        // 保留原有的滑鼠點擊功能
        if (Input.GetMouseButtonDown(0))
        {
            Vector3 hitDirection = (transform.position - GetMouseWorldPosition()).normalized;
            ApplyForceToBag(hitDirection);
            StartCoroutine(ScreenShake());
            Debug.Log("Mouse punch detected!");
        }

        // Kinect 身體追蹤
        UpdateBodyFrame();
    }

    void UpdateBodyFrame()
    {
        if (bodyFrameReader != null)
        {
            using (BodyFrame bodyFrame = bodyFrameReader.AcquireLatestFrame())
            {
                if (bodyFrame != null)
                {
                    bodyFrame.GetAndRefreshBodyData(bodies);

                    foreach (Body body in bodies)
                    {
                        if (body.IsTracked)
                        {
                            DetectRightPunch(body);
                            DetectLeftPunch(body);
                        }
                    }
                }
            }
        }
    }

    private void DetectRightPunch(Body body)
    {
        var rightHand = body.Joints[JointType.HandRight].Position;
        Vector3 rightHandPos = new Vector3(rightHand.X, rightHand.Y, rightHand.Z);

        if (rightHandHistory.Count >= historySize)
        {
            rightHandHistory.RemoveAt(0);
        }
        rightHandHistory.Add(rightHandPos);

        float speed = CalculateSmoothedSpeed(rightHandHistory);
        float distanceMoved = CalculateDistanceMoved(rightHandHistory);

        if (speed > basePunchSpeedThreshold && distanceMoved > basePunchDistanceThreshold)
        {
            float currentTime = Time.time;
            if (currentTime - lastRightPunchTime >= cooldownTime)
            {
                Debug.Log("檢測到右手揮拳動作！");
                ApplyForceToBag((rightHandPos - transform.position).normalized);
                lastRightPunchTime = currentTime;

                feedback.RegisterHit();
                StartCoroutine(ScreenShake());
            }
        }

        previousRightHandPos = rightHandPos;
    }

    private void DetectLeftPunch(Body body)
    {
        var leftHand = body.Joints[JointType.HandLeft].Position;
        Vector3 leftHandPos = new Vector3(leftHand.X, leftHand.Y, leftHand.Z);

        if (leftHandHistory.Count >= historySize)
        {
            leftHandHistory.RemoveAt(0);
        }
        leftHandHistory.Add(leftHandPos);

        float speed = CalculateSmoothedSpeed(leftHandHistory);
        float distanceMoved = CalculateDistanceMoved(leftHandHistory);

        if (speed > basePunchSpeedThreshold && distanceMoved > basePunchDistanceThreshold)
        {
            float currentTime = Time.time;
            if (currentTime - lastLeftPunchTime >= cooldownTime)
            {
                Debug.Log("檢測到左手揮拳動作！");
                ApplyForceToBag((leftHandPos - transform.position).normalized);
                lastLeftPunchTime = currentTime;

                feedback.RegisterHit();
                StartCoroutine(ScreenShake());
            }
        }

        previousLeftHandPos = leftHandPos;
    }

    private float CalculateSmoothedSpeed(List<Vector3> handHistory)
    {
        if (handHistory.Count < 2) return 0f;

        float smoothedSpeed = 0f;
        float alpha = 0.1f; // 平滑因子
        Vector3 prevPos = handHistory[0];

        foreach (var pos in handHistory)
        {
            float speed = (pos - prevPos).magnitude / Time.deltaTime;
            smoothedSpeed = alpha * speed + (1 - alpha) * smoothedSpeed;
            prevPos = pos;
        }

        return smoothedSpeed;
    }

    private float CalculateDistanceMoved(List<Vector3> handHistory)
    {
        if (handHistory.Count < 2) return 0f;

        float initialZ = handHistory[0].z;
        float finalZ = handHistory[handHistory.Count - 1].z;

        return Mathf.Abs(finalZ - initialZ);
    }

    Vector3 GetMouseWorldPosition()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out RaycastHit hit))
        {
            return hit.point;
        }
        return Vector3.zero;
    }

    void ApplyForceToBag(Vector3 direction)
    {
        rb.AddForce(direction * hitForce, ForceMode.Impulse);
    }

    System.Collections.IEnumerator ScreenShake()
    {
        if (isShaking) yield break;

        isShaking = true;
        float elapsed = 0.0f;

        while (elapsed < shakeDuration)
        {
            Vector3 randomOffset = Random.insideUnitSphere * shakeMagnitude;
            mainCamera.transform.position = originalCameraPosition + randomOffset;

            elapsed += Time.deltaTime;
            yield return null;
        }

        mainCamera.transform.position = originalCameraPosition;
        isShaking = false;
    }

    void OnDestroy()
    {
        if (bodyFrameReader != null)
        {
            bodyFrameReader.Dispose();
            bodyFrameReader = null;
        }

        if (kinectSensor != null)
        {
            if (kinectSensor.IsOpen)
            {
                kinectSensor.Close();
            }
            kinectSensor = null;
        }
    }
}
