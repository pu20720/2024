using UnityEngine;
using System.Collections;

public class PunchingEnemy : MonoBehaviour
{
    // 定義防禦和後退的事件
    public delegate void DefenseHandler(float duration);
    public static event DefenseHandler OnDefenseStart;

    public delegate void BackwardHandler(float duration);
    public static event BackwardHandler OnBackwardStart;

    private Animator animator;
    private bool isDefending = false;

    // 動作的冷卻時間（秒）
    private float rightPunchCooldown = 2.0f;
    private float leftPunchCooldown = 2.0f;
    private float idleCooldown = 1.0f;
    private float defenseCooldown = 2.0f;
    private float backwardCooldown = 2.0f;

    // 防禦和後退的不計分時間（秒）
    private float defenseDuration = 1.0f;
    private float backwardDuration = 1.0f;

    private float lastRightPunchTime = -1.0f;
    private float lastLeftPunchTime = -1.0f;
    private float lastIdleTime = -1.0f;
    private float lastDefenseTime = -1.0f;
    private float lastBackwardTime = -1.0f;

    void Start()
    {
        animator = GetComponent<Animator>();
        StartCoroutine(ActionRoutine()); // 啟動動作執行協程

        GestureDetector detector = FindObjectOfType<GestureDetector>();
        if (detector != null)
        {
            detector.OnGestureDetected += HandleGestureDetected;
        }
    }

    IEnumerator ActionRoutine()
    {
        while (true)
        {
            if (!isDefending) // 只有在不防禦的情況下才執行動作
            {
                float currentTime = Time.time;

                // 檢查每個動作的冷卻時間是否已過
                if (currentTime - lastRightPunchTime >= rightPunchCooldown && Random.value < 0.4f)
                {
                    TriggerAnimation("PunchR"); // 觸發右拳攻擊動畫
                    lastRightPunchTime = currentTime;
                }
                else if (currentTime - lastLeftPunchTime >= leftPunchCooldown && Random.value < 0.4f)
                {
                    TriggerAnimation("PunchL"); // 觸發左拳攻擊動畫
                    lastLeftPunchTime = currentTime;
                }
                else if (currentTime - lastIdleTime >= idleCooldown && Random.value < 0.01f)
                {
                    TriggerAnimation("Idle"); // 觸發閒置動畫
                    lastIdleTime = currentTime;
                }
            }
            yield return new WaitForSeconds(2f); // 每2秒檢查一次
        }
    }

    // 處理手勢偵測事件
    private void HandleGestureDetected(int gestureCode)
    {
        switch (gestureCode)
        {
            case 1: // 右手揮拳
                if (Random.value < 0.1f) AttemptDefense(); // 10%機率防禦
                if (Random.value < 0.35f) AttemptBackwardMove(); // 35%機率後退
                break;
            case 2: // 左手揮拳
                if (Random.value < 0.35f) AttemptDefense(); // 35%機率防禦
                if (Random.value < 0.1f) AttemptBackwardMove(); // 10%機率後退
                break;
            case 3: // 防禦手勢
                if (Random.value < 0.1f) TriggerAnimation("PunchR"); // 觸發右拳攻擊動畫
                if (Random.value < 0.2f) TriggerAnimation("PunchL"); // 觸發左拳攻擊動畫
                if (Random.value < 0.15f) AttemptDefense(); // 15%機率防禦
                break;
            case 4: // 後退手勢
                if (Random.value < 0.2f) TriggerAnimation("PunchR"); // 觸發右拳攻擊動畫
                if (Random.value < 0.1f) TriggerAnimation("PunchL"); // 觸發左拳攻擊動畫
                if (Random.value < 0.15f) AttemptBackwardMove(); // 15%機率後退
                break;
            default:
                break;
        }
    }

    // 嘗試進行防禦
    public void AttemptDefense()
    {
        float currentTime = Time.time;
        // 檢查防禦冷卻時間是否已過
        if (currentTime - lastDefenseTime >= defenseCooldown)
        {
            isDefending = true; // 設置為防禦狀態
            TriggerAnimation("Defense"); // 觸發防禦動畫
            lastDefenseTime = currentTime;

            OnDefenseStart?.Invoke(defenseDuration); // 通知防禦狀態開始
            StartCoroutine(EndDefenseRoutine()); // 開啟結束防禦的協程
        }
    }

    // 嘗試進行後退
    public void AttemptBackwardMove()
    {
        float currentTime = Time.time;
        // 檢查後退冷卻時間是否已過
        if (currentTime - lastBackwardTime >= backwardCooldown)
        {
            TriggerAnimation("Backward"); // 觸發後退動畫
            lastBackwardTime = currentTime;

            OnBackwardStart?.Invoke(backwardDuration); // 通知後退不計分開始
        }
    }

    // 結束防禦狀態的協程
    IEnumerator EndDefenseRoutine()
    {
        yield return new WaitForSeconds(defenseDuration); // 防禦不計分時間
        isDefending = false; // 結束防禦狀態
    }

    // 觸發動畫
    private void TriggerAnimation(string action)
    {
        animator.SetTrigger(action); // 設置對應的動畫觸發器
    }

    private void OnDestroy()
    {
        // 確保在對象銷毀時取消訂閱事件
        GestureDetector detector = FindObjectOfType<GestureDetector>();
        if (detector != null)
        {
            detector.OnGestureDetected -= HandleGestureDetected;
        }
    }
}
