using UnityEngine;
using TMPro;

public class Feedback : MonoBehaviour
{
    public TMP_Text feedbackText;
    public TMP_Text comboText;           // Combo 顯示文字
    public AudioSource audioSource;

    private float timeWindow = 2f;
    private int clickCount = 0;
    private float feedbackTimer = 0f;
    private bool canGenerateFeedback = true;
    private bool isCountingData = false; // 控制統計開關

    // 統計變數
    public int FeedbackDisplayCount { get; private set; }
    public int TotalClicks { get; private set; }
    public int WeakCount { get; private set; }
    public int ModerateCount { get; private set; }
    public int StrongCount { get; private set; }

    // Combo 計算
    private int comboCount = 0;
    private float comboResetTime = 2f;  // Combo 重置時間
    private float lastHitTime;          // 最後一次擊中時間

    public void StartCountingData() => isCountingData = true;  // 開始計算數據
    public void StopCountingData() => isCountingData = false;  // 停止計算數據

    void Update()
    {
        if (isCountingData)
        {
            feedbackTimer += Time.deltaTime;

            if (feedbackTimer >= timeWindow && canGenerateFeedback)
            {
                GenerateFeedback();
                feedbackTimer = 0f;
                clickCount = 0;
                canGenerateFeedback = false;
            }

            if (feedbackTimer >= timeWindow)
            {
                canGenerateFeedback = true;
            }
        }
    }

    public void RegisterClick()
    {
        if (isCountingData)
        {
            clickCount++;
            TotalClicks++;
            CalculateCombo(); // 計算 Combo
        }
        PlaySound();
    }

    public void RegisterHit()
    {
        RegisterClick();  // 直接使用 RegisterClick 來累加數據
    }

    private void CalculateCombo()
    {
        float currentTime = Time.time;

        // 如果在重置時間內，增加 Combo 計數
        if (currentTime - lastHitTime <= comboResetTime)
        {
            comboCount++;
        }
        else
        {
            comboCount = 1; // 超時重置 Combo 計數
        }

        lastHitTime = currentTime;

        // 更新 Combo 顯示
        comboText.text = "Combo: " + comboCount;

        // 啟動文字動畫
        StartCoroutine(AnimateComboText());
    }

    private System.Collections.IEnumerator AnimateComboText()
    {
        comboText.transform.localScale = Vector3.one * 1.5f;
        yield return new WaitForSeconds(0.1f);
        comboText.transform.localScale = Vector3.one;
    }

    void GenerateFeedback()
    {
        FeedbackDisplayCount++;
        if (clickCount < 2)
        {
            feedbackText.text = "太弱了，試試打得更快吧！";
            feedbackText.color = Color.red;
            WeakCount++;
        }
        else if (clickCount >= 2 && clickCount <= 4)
        {
            feedbackText.text = "不錯，繼續保持節奏！";
            feedbackText.color = Color.yellow;
            ModerateCount++;
        }
        else
        {
            feedbackText.text = "速度極快，打擊威力大！";
            feedbackText.color = Color.green;
            StrongCount++;
        }
    }

    void PlaySound()
    {
        if (audioSource != null)
        {
            audioSource.Play();
        }
    }
}
