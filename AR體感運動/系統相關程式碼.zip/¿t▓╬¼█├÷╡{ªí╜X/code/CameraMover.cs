
// CameraMover.cs
using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class CameraMover : MonoBehaviour
{
    public Transform targetPosition;
    public float moveDuration = 2.0f;
    public Button moveCameraButton;

    private bool isMoving = false;
    private Camera cameraToMove;

    void Start()
    {
        cameraToMove = Camera.main;
        if (moveCameraButton != null)
        {
            moveCameraButton.onClick.AddListener(StartMovingCamera);
        }
    }

    public void UpdateTargetPosition(Transform newTargetPosition)
    {
        targetPosition = newTargetPosition;
    }

    public void StartMovingCamera()
    {
        if (!isMoving && targetPosition != null && cameraToMove != null)
        {
            StartCoroutine(MoveCamera());
        }
    }

    IEnumerator MoveCamera()
    {
        isMoving = true;

        Vector3 startPosition = cameraToMove.transform.position;
        Quaternion startRotation = cameraToMove.transform.rotation;
        Vector3 endPosition = targetPosition.position;

        float elapsedTime = 0f;

        while (elapsedTime < moveDuration)
        {
            cameraToMove.transform.position = Vector3.Lerp(startPosition, endPosition, elapsedTime / moveDuration);

            elapsedTime += Time.deltaTime;
            yield return null;
        }

        cameraToMove.transform.position = endPosition;

        if (GameManager.Instance != null)
        {
            // 更新 GameManager 中保存的返回位置
            GameManager.Instance.returnPosition = endPosition;
        }

        isMoving = false;
    }
}