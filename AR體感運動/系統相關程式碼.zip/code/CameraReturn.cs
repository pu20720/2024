using UnityEngine;
using UnityEngine.UI;

public class CameraReturn : MonoBehaviour
{
    public Vector3 originalPosition = new Vector3(1752.9f, 552.2f, 18579.7f); // 相機初始位置
    public Vector3 targetPosition = new Vector3(-32.7f, 523.4f, 5780.7f); // 自定義目標位置
    public float returnDuration = 2.0f; // 返回初始位置的時間
    public Button returnButton; // 返回按鈕
    private Camera mainCamera; // 主相機
    private bool isReturning = false; // 是否正在返回
    private bool hasReachedTarget = false; // 是否已經到達目標位置
    void Start()
    {
        mainCamera = Camera.main;
        returnButton.gameObject.SetActive(false); // 初始化隱藏按鈕

        if (returnButton != null)
        {
            returnButton.onClick.AddListener(ReturnToOriginal);
        }
    }

    void Update()
    {
        // 檢查相機是否到達目標位置，使用小於指定的距離範圍
        if (!isReturning && !hasReachedTarget && Vector3.Distance(mainCamera.transform.position, targetPosition) <= 0.1f)
        {
            hasReachedTarget = true;
            returnButton.gameObject.SetActive(true); // 顯示按鈕
        }
        else if (!isReturning && hasReachedTarget && Vector3.Distance(mainCamera.transform.position, targetPosition) >= 0.1f)
        {
            hasReachedTarget = false;
            returnButton.gameObject.SetActive(false); // 隱藏按鈕
        }
    }

    void ReturnToOriginal()
    {
        if (!isReturning && mainCamera != null)
        {
            StartCoroutine(MoveBack());
        }
    }

    System.Collections.IEnumerator MoveBack()
    {
        isReturning = true;
        Vector3 startPosition = mainCamera.transform.position;
        float elapsedTime = 0f;

        while (elapsedTime < returnDuration)
        {
            mainCamera.transform.position = Vector3.Lerp(startPosition, originalPosition, elapsedTime / returnDuration);
            elapsedTime += Time.deltaTime;
            yield return null;
        }

        mainCamera.transform.position = originalPosition; // 確保位置精確
        isReturning = false;
        returnButton.gameObject.SetActive(false); // 隱藏按鈕
    }
}
