using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
using System.Collections;

public class game3 : MonoBehaviour
{
    public Feedback feedback;             // 反饋系統
    public GameObject rulesPanel;         // 規則面板
    public GameObject gamePanel;          // 遊戲面板
    public GameObject gameOverPanel;      // 遊戲結束面板
    public TextMeshProUGUI countdownText; // 倒數計時文字
    public TextMeshProUGUI timerText;     // 遊戲計時文字
    public TextMeshProUGUI gameOverText;  // 遊戲結束文字

    private float countdownTime = 5f;    // 倒數計時時間
    private float gameTime = 30f;         // 遊戲時間
    private bool gameStarted = false;     // 是否開始遊戲
    private bool gameOver = false;        // 是否遊戲結束

    void Start()
    {
        // 初始化 UI 狀態
        rulesPanel.SetActive(true);
        gamePanel.SetActive(false);
        gameOverPanel.SetActive(false);

        feedback.comboText.text = ""; // 初始化 Combo 顯示文字
        StartCoroutine(StartGameCountdown());
    }

    IEnumerator StartGameCountdown()
    {
        // 倒數計時迴圈，暫停時間流動
        Time.timeScale = 0;
        while (countdownTime > 0)
        {
            countdownText.text = "開始前倒數: " + Mathf.Ceil(countdownTime).ToString();
            yield return new WaitForSecondsRealtime(1f); // 使用實際時間倒數
            countdownTime--;
        }

        countdownText.text = "Go!";
        yield return new WaitForSecondsRealtime(1f); // 延遲一秒顯示 "開始!"

        // 恢復時間流動，切換至遊戲畫面
        Time.timeScale = 1;
        rulesPanel.SetActive(false);
        gamePanel.SetActive(true);
        gameStarted = true;

        feedback.StartCountingData(); // 開始反饋統計
        StartCoroutine(GameTimer());
    }

    IEnumerator GameTimer()
    {
        // 遊戲計時迴圈
        while (gameTime > 0)
        {
            if (gameOver) yield break;

            timerText.text = "剩餘時間: " + gameTime.ToString("F0") + "s";
            yield return new WaitForSeconds(1f);
            gameTime--;
        }

        EndGame();
    }

    void EndGame()
    {
        gameStarted = false;
        gameOver = true;

        gamePanel.SetActive(false);
        gameOverPanel.SetActive(true);

        feedback.StopCountingData(); // 結束反饋統計

        // 顯示詳細統計
        gameOverText.text = $"遊戲結束!\n" +
                            $"總打擊數: {feedback.TotalClicks}\n" +
                            $"弱打擊: {feedback.WeakCount} 次\n" +
                            $"適中打擊: {feedback.ModerateCount} 次\n" +
                            $"強打擊: {feedback.StrongCount} 次\n" +
                            $"每秒平均打擊數: {feedback.TotalClicks / 30f:F2} 次";
    }

    void Update()
    {
        if (gameStarted && !gameOver && Input.GetMouseButtonDown(0))
        {
            feedback.RegisterClick(); // 註冊點擊
        }

        if (gameOver && Input.anyKeyDown)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name); // 重新加載場景
        }
    }
}