using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    
    public Vector3 returnPosition;
    public bool isReturningToMain = false;
    private bool hasMoved = false;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (isReturningToMain && scene.name == "Main" && !hasMoved)
        {
            // 等待一幀確保所有物件都已初始化
            StartCoroutine(MoveCameraAfterDelay());
        }
    }

    System.Collections.IEnumerator MoveCameraAfterDelay()
    {
        yield return new WaitForSeconds(0f);
        MoveCameraToReturnPosition();
        hasMoved = true;
        isReturningToMain = false;
    }

    public void MoveCameraToReturnPosition()
    {
        if (Camera.main != null)
        {
            Debug.Log($"Moving camera to position: {returnPosition}");
            Camera.main.transform.position = returnPosition;
        }
        else
        {
            Debug.LogWarning("Main camera not found!");
        }
    }

    // 當開始新的模式時重置標誌
    public void ResetFlags()
    {
        hasMoved = false;
        isReturningToMain = true;
    }
}