using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class GameController : MonoBehaviour
{
    public static GameController instance;

    public int button1Count = 0;
    public int button2Count = 0;
    public int button3Count = 0;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void OnButton1Pressed()
    {
        button1Count++;
    }

    public void OnButton2Pressed()
    {
        button2Count++;
    }

    public void OnButton3Pressed()
    {
        button3Count++;
    }

    public void OnSettlementPressed()
    {
        SceneManager.LoadScene("Level2");
    }

    public void OnMenuPressed()
    {
        SceneManager.LoadScene("MainMenu");
        Destroy(gameObject); // 回到菜单时销毁 GameController 实例
    }
}
