using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using Windows.Kinect;

public class ExitGame : MonoBehaviour
{
    private KinectSensor sensor;
    private BodyFrameReader bodyFrameReader;
    private Body[] bodies;

    private float angleThreshold = 60.0f;
    private float headHandDistanceThreshold = 0.35f;
    private bool isExiting = false;

    // 設置當前模式編號（由外部腳本設置）
    public int currentMode = 1;

    void Start()
    {
        // 初始化 Kinect 資源
        sensor = KinectSensor.GetDefault();
        if (sensor != null)
        {
            bodyFrameReader = sensor.BodyFrameSource.OpenReader();
            if (!sensor.IsOpen)
            {
                sensor.Open();
            }
        }
    }

    void Update()
    {
        if (bodyFrameReader != null && !isExiting)
        {
            var frame = bodyFrameReader.AcquireLatestFrame();
            if (frame != null)
            {
                if (bodies == null)
                {
                    bodies = new Body[sensor.BodyFrameSource.BodyCount];
                }

                frame.GetAndRefreshBodyData(bodies);
                frame.Dispose();
                frame = null;

                foreach (var body in bodies)
                {
                    if (body != null && body.IsTracked)
                    {
                        DetectHandRaised(body);
                    }
                }
            }
        }
    }

    private void DetectHandRaised(Body body)
    {
        var head = GetVector3FromJoint(body.Joints[JointType.Head]);
        var leftHand = GetVector3FromJoint(body.Joints[JointType.HandLeft]);
        var rightHand = GetVector3FromJoint(body.Joints[JointType.HandRight]);

        if (IsHandAboveHead(leftHand, head) && IsHandAboveHead(rightHand, head))
        {
            Debug.Log("偵測到雙手都在都在頭部之上, 準備退回 Main 場景");
            StartCoroutine(ReturnToMainScene());
        }
    }

    private IEnumerator ReturnToMainScene()
    {
        if (isExiting) yield break;
        isExiting = true;

        // 將當前模式保存到 PlayerPrefs
        PlayerPrefs.SetInt("LastMode", currentMode);
        PlayerPrefs.Save();
        Debug.Log($"保存模式: {currentMode} 並返回 Main");

        yield return new WaitForSeconds(0.2f); // 短暫延遲，防止初始化衝突

        if (GameManager.Instance != null)
        {
            GameManager.Instance.isReturningToMain = true;
            GameManager.Instance.ResetFlags(); // 重置 GameManager 的標誌
        }

        SceneManager.LoadScene("Main");

        yield return null;

        // 保證在場景加載後再釋放 Kinect
        yield return new WaitForSeconds(0.2f); // 確保新場景初始化完成

        if (GameManager.Instance != null)
        {
            GameManager.Instance.MoveCameraToReturnPosition();
        }

        // 釋放 Kinect 資源
        if (bodyFrameReader != null)
        {
            bodyFrameReader.Dispose();
            bodyFrameReader = null;
        }

        if (sensor != null)
        {
            if (sensor.IsOpen)
            {
                sensor.Close();
            }
            sensor = null;
        }

        isExiting = false;
    }

    private bool IsHandAboveHead(Vector3 handPos, Vector3 headPos)
    {
        float angle = Vector3.Angle(Vector3.up, handPos - headPos);
        float distance = Vector3.Distance(handPos, headPos);

        return angle < angleThreshold && distance > headHandDistanceThreshold;
    }

    private Vector3 GetVector3FromJoint(Windows.Kinect.Joint joint)
    {
        return new Vector3(joint.Position.X, joint.Position.Y, joint.Position.Z);
    }

    private void OnApplicationQuit()
    {
        // 不再在這裡釋放 Kinect 資源，避免干擾場景切換
        Debug.Log("應用退出，但不釋放 Kinect 資源");
    }
}
