using UnityEngine;

public class PunchingBag : MonoBehaviour
{
    public float hitForce = 10f; // 打击力
    private Rigidbody rb; // 刚体引用
    public TutorialManager tutorialManager; // 引用TutorialManager脚本
    private Animator animator;
    void Start()
    {
        rb = GetComponent<Rigidbody>(); // 获取刚体组件
        animator = GetComponent<Animator>();
    }

    public void PlayDefense()
    {
        animator.SetTrigger("Defense");
    }

    public void PlayIdle()
    {
        animator.Play("Idle");
    }

    // 当碰撞发生时调用
    void OnCollisionEnter(Collision collision)
    {
        // 只检测自己（PunchingBag）的部位，而不是对方
        DetectHitPart(collision.contacts[0].thisCollider); // thisCollider是自己被碰到的部位
    }

    void ApplyForceToBag(Vector3 direction)
    {
        rb.AddForce(direction * hitForce, ForceMode.Impulse); // 根据方向和力对沙袋施加冲击力
    }

    void DetectHitPart(Collider hitCollider)
    {
        // 检测碰撞到沙袋的哪个部位
        if (hitCollider.CompareTag("Head")) // 如果碰撞到的部分是头部
        {
            tutorialManager.RegisterHit("Head"); // 通知TutorialManager击中了头部
        }
        else if (hitCollider.CompareTag("Body")) // 如果碰撞到的部分是身体
        {
            tutorialManager.RegisterHit("Body"); // 通知TutorialManager击中了身体
        }
        else if (hitCollider.CompareTag("Hand")) // 如果碰撞到的部分是手部
        {
            tutorialManager.RegisterHit("Hand"); // 通知TutorialManager击中了手部
        }
    }
}
