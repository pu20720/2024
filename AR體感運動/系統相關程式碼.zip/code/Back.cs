using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Back : MonoBehaviour
{
   public string Level;

   public void BackToMain()
   {
      SceneManager.LoadScene(Level);
   }
}
