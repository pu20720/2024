using UnityEngine;
using Windows.Kinect;
using System.Collections;

public class Kinect_menu : MonoBehaviour
{
    private KinectSensor sensor;  // Kinect傳感器
    private BodyFrameReader bodyFrameReader;  // 身體框架讀取器
    private Body[] bodies;  // 用來存儲身體數據的陣列

    private bool isSwipingLeft = false;  // 標記是否進行了左揮
    private bool isSwipingRight = false;  // 標記是否進行了右揮
    private bool isHoldingHead = false;  // 標記是否進行了雙手抱頭

    private Vector3 rightHandStartPos;  // 右手起始位置
    private float swipeStartTime;  // 揮手開始時間
    private Vector3 lastHandPosition;  // 右手上一幀的位置
    private float lastUpdateTime;  // 右手上一幀的時間

    private float swipeThreshold = 0.3f;  // 揮手位移閾值(公尺)
    private float swipeTimeLimit = 0.5f;  // 揮手動作的時間限制(秒)
    private float speedThreshold = 0.8f;  // 揮手速度閾值(公尺/秒)
    private float swipeCooldownTime = 1.2f;  // 冷卻時間(秒)
    private bool canSwipe = true;  // 是否可以進行揮手動作
    private bool canPunch = true;  // 是否可以進行雙手抱頭動作

    void Start()
    {
        StartCoroutine(DelayedStart()); // 啟動延遲初始化協程
        /*
        // 初始化 Kinect 感應器
        sensor = KinectSensor.GetDefault();
        if (sensor != null)
        {
            bodyFrameReader = sensor.BodyFrameSource.OpenReader();  // 開啟身體數據讀取器
            if (!sensor.IsOpen)
            {
                sensor.Open();  // 如果感應器尚未開啟，則開啟它
            }
        }
        */
    }

    private IEnumerator DelayedStart()
    {
        // 等待一段時間
        yield return new WaitForSeconds(1f);

        // 初始化 Kinect 感應器
        sensor = KinectSensor.GetDefault();
        if (sensor != null)
        {
            bodyFrameReader = sensor.BodyFrameSource.OpenReader(); // 開啟身體資料讀取器
            if (!sensor.IsOpen)
            {
                sensor.Open(); // 如果感測器尚未開啟，則開啟它
            }
        }
    }
    void Update()
    {
        if (bodyFrameReader != null)
        {
            var frame = bodyFrameReader.AcquireLatestFrame();
            if (frame != null)
            {
                if (bodies == null)
                {
                    bodies = new Body[sensor.BodyFrameSource.BodyCount];
                }

                frame.GetAndRefreshBodyData(bodies);
                frame.Dispose();
                frame = null;

                foreach (var body in bodies)
                {
                    if (body != null && body.IsTracked)
                    {
                        if (canSwipe)
                        {
                            DetectSwipe(body);
                        }
                        if (canPunch)
                        {
                            DetectHeadHold(body);
                        }
                    }
                }
            }
        }
    }

    private void DetectSwipe(Body body)
    {
        var rightHandPos = GetVector3FromJoint(body.Joints[JointType.HandRight]);
        float currentTime = Time.time;

        if (rightHandStartPos == Vector3.zero)
        {
            rightHandStartPos = rightHandPos;
            swipeStartTime = currentTime;
            lastHandPosition = rightHandPos;
            lastUpdateTime = currentTime;
            return;
        }

        float elapsedTime = currentTime - swipeStartTime;

        // 計算當前速度
        float frameSpeed = (rightHandPos - lastHandPosition).magnitude / (currentTime - lastUpdateTime);

        // 偵測是否符合揮手條件
        if (elapsedTime <= swipeTimeLimit && frameSpeed >= speedThreshold)
        {
            if (rightHandPos.x - rightHandStartPos.x > swipeThreshold)
            {
                isSwipingLeft = true;
                Debug.Log("快速左揮");
                StartCoroutine(DisableSwipeTemporarily());
                ResetSwipe();
            }
            else if (rightHandPos.x - rightHandStartPos.x < -swipeThreshold)
            {
                isSwipingRight = true;
                Debug.Log("快速右揮");
                StartCoroutine(DisableSwipeTemporarily());
                ResetSwipe();
            }
        }
        else if (elapsedTime > swipeTimeLimit)
        {
            // 超過時間限制則重置
            ResetSwipe();
        }

        // 更新上一幀的數據
        lastHandPosition = rightHandPos;
        lastUpdateTime = currentTime;
    }

    private void ResetSwipe()
    {
        rightHandStartPos = Vector3.zero;
        swipeStartTime = 0;
    }

    private void DetectHeadHold(Body body)
    {
        var leftHandPos = GetVector3FromJoint(body.Joints[JointType.HandLeft]);
        var rightHandPos = GetVector3FromJoint(body.Joints[JointType.HandRight]);
        var headPos = GetVector3FromJoint(body.Joints[JointType.Head]);

        float distanceThreshold = 0.25f;  // 雙手距離頭部的距離

        bool isLeftHandNearHead = Vector3.Distance(leftHandPos, headPos) < distanceThreshold;
        bool isRightHandNearHead = Vector3.Distance(rightHandPos, headPos) < distanceThreshold;

        if (isLeftHandNearHead && isRightHandNearHead)
        {
            isHoldingHead = true;
            Debug.Log("雙手抱頭");
            StartCoroutine(DisablePunchTemporarily());
        }
    }

    IEnumerator DisableSwipeTemporarily()
    {
        canSwipe = false;
        yield return new WaitForSeconds(swipeCooldownTime);
        canSwipe = true;
    }

    IEnumerator DisablePunchTemporarily()
    {
        canPunch = false;
        yield return new WaitForSeconds(swipeCooldownTime);
        canPunch = true;
    }

    private Vector3 GetVector3FromJoint(Windows.Kinect.Joint joint)
    {
        return new Vector3(joint.Position.X, joint.Position.Y, joint.Position.Z);
    }

    public bool GetAndResetSwipeLeft()
    {
        if (isSwipingLeft)
        {
            isSwipingLeft = false;
            return true;
        }
        return false;
    }

    public bool GetAndResetSwipeRight()
    {
        if (isSwipingRight)
        {
            isSwipingRight = false;
            return true;
        }
        return false;
    }

    public bool GetAndResetHeadHold()
    {
        if (isHoldingHead)
        {
            isHoldingHead = false;
            return true;
        }
        return false;
    }
    public void ResetGestureDetection()
    {
        // 重置手勢偵測狀態
        isSwipingLeft = false;
        isSwipingRight = false;
        isHoldingHead = false;
        rightHandStartPos = Vector3.zero;
        swipeStartTime = 0;
        lastHandPosition = Vector3.zero;
        lastUpdateTime = 0;
        canSwipe = true;
        canPunch = true;
        Debug.Log("Kinect手勢偵測狀態已重置");
    }
    private void OnApplicationQuit()
    {
        if (bodyFrameReader != null)
        {
            bodyFrameReader.Dispose();
            bodyFrameReader = null;
        }

        if (sensor != null)
        {
            if (sensor.IsOpen)
            {
                sensor.Close();
            }
            sensor = null;
        }
    }
}
