using UnityEngine;
using System.Collections;

public class HitBox : MonoBehaviour
{
    public string playerTag = "Player";
    public string opponentTag = "Opponent";
    public ScoringSystem scoringSystem;
    private bool hasScored = false;
    private float scoreCooldown = 1f;
    private float lastScoreTime = 0f;

    private bool disableHeadScore = false; // 防禦狀態時禁用頭部得分
    private bool disableBodyScore = false; // 後退狀態時禁用身體得分

    public Animator playerAnimator; // 玩家動畫控制器
    public Animator opponentAnimator; // 對手動畫控制器

    public Transform cameraTransform;        // 主攝影機的 Transform
    private float shakeDuration = 0.04f;       // 晃動持續時間
    private float shakeMagnitude = 0.2f;      // 晃動強度
    private Vector3 originalCameraPosition;  // 攝影機的原始位置

    public AudioClip headHitSound;    // 頭部擊中音效
    public AudioClip bodyHitSound;    // 身體擊中音效
    private AudioSource audioSource;  // 用於播放音效的音頻源

    [Range(0f, 1f)] public float soundVolume = 0.8f; // 音效音量範圍 0~1

    private void Start()
    {
        // 初始化 AudioSource
        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.playOnAwake = false; // 確保不會自動播放音效

        // 訂閱對手的防禦和後退事件
        PunchingEnemy.OnDefenseStart += DisableHeadScoreTemporarily;
        PunchingEnemy.OnBackwardStart += DisableBodyScoreTemporarily;

        if (cameraTransform != null)
        {
            originalCameraPosition = cameraTransform.localPosition; // 保存攝影機的原始位置
        }
        else
        {
            Debug.LogError("Camera Transform is not assigned in HitBox script!");
        }
    }

    private void DisableHeadScoreTemporarily(float duration)
    {
        StartCoroutine(TemporarilyDisableHeadScore(duration));
    }

    private void DisableBodyScoreTemporarily(float duration)
    {
        StartCoroutine(TemporarilyDisableBodyScore(duration));
    }

    private IEnumerator TemporarilyDisableHeadScore(float duration)
    {
        disableHeadScore = true; // 禁用頭部得分
        yield return new WaitForSeconds(duration);
        disableHeadScore = false; // 恢復頭部得分
    }

    private IEnumerator TemporarilyDisableBodyScore(float duration)
    {
        disableBodyScore = true; // 禁用身體得分
        yield return new WaitForSeconds(duration);
        disableBodyScore = false; // 恢復身體得分
    }

    private void OnTriggerEnter(Collider other)
    {
        if (Time.time - lastScoreTime < scoreCooldown) return;
        if (other.gameObject == gameObject) return;

        if (gameObject.CompareTag(playerTag) && (other.CompareTag("oHead") || other.CompareTag("oBody")) && other.transform.root.CompareTag(opponentTag))
        {
            if (!hasScored)
            {
                if (other.CompareTag("oHead") && !disableHeadScore) // 檢查防禦狀態
                {
                    scoringSystem.AddPlayerScore(3);
                    opponentAnimator.SetTrigger("HeadHit"); // 對手頭部受擊動畫
                    PlaySound(headHitSound); // 播放頭部擊中音效
                    StartCoroutine(ShakeCamera()); // 擊中對手時晃動鏡頭
                }
                else if (other.CompareTag("oBody") && !disableBodyScore) // 檢查後退狀態
                {
                    scoringSystem.AddPlayerScore(2);
                    opponentAnimator.SetTrigger("BodyHit"); // 對手身體受擊動畫
                    PlaySound(bodyHitSound); // 播放身體擊中音效
                    StartCoroutine(ShakeCamera()); // 擊中對手時晃動鏡頭
                }

                Debug.Log("Player得分!");
                hasScored = true;
                lastScoreTime = Time.time;
            }
        }
        else if (gameObject.CompareTag(opponentTag) && (other.CompareTag("Head") || other.CompareTag("Body")) && other.transform.root.CompareTag(playerTag))
        {
            if (!hasScored)
            {
                if (other.CompareTag("Head") && !disableHeadScore) // 檢查防禦狀態
                {
                    scoringSystem.AddOpponentScore(3);
                    playerAnimator.SetTrigger("HeadHit"); // 玩家頭部受擊動畫
                    PlaySound(headHitSound); // 播放頭部擊中音效
                    StartCoroutine(ShakeCamera()); // 擊中玩家時晃動鏡頭
                }
                else if (other.CompareTag("Body") && !disableBodyScore) // 檢查後退狀態
                {
                    scoringSystem.AddOpponentScore(2);
                    playerAnimator.SetTrigger("BodyHit"); // 玩家身體受擊動畫
                    PlaySound(bodyHitSound); // 播放身體擊中音效
                    StartCoroutine(ShakeCamera()); // 擊中玩家時晃動鏡頭
                }

                Debug.Log("Opponent得分!");
                hasScored = true;
                lastScoreTime = Time.time;
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if ((other.CompareTag("oBody") || other.CompareTag("oHead")) && gameObject.CompareTag(playerTag))
        {
            hasScored = false;
        }
        else if ((other.CompareTag("Body") || other.CompareTag("Head")) && gameObject.CompareTag(opponentTag))
        {
            hasScored = false;
        }
    }

    private void OnDestroy()
    {
        // 確保在對象銷毀時取消訂閱事件
        PunchingEnemy.OnDefenseStart -= DisableHeadScoreTemporarily;
        PunchingEnemy.OnBackwardStart -= DisableBodyScoreTemporarily;
    }

    private IEnumerator ShakeCamera()
    {
        float elapsedTime = 0f;

        while (elapsedTime < shakeDuration)
        {
            Vector3 randomOffset = Random.insideUnitSphere * shakeMagnitude; // 隨機位置偏移
            cameraTransform.localPosition = originalCameraPosition + randomOffset;

            elapsedTime += Time.deltaTime;
            yield return null; // 等待下一幀
        }

        // 恢復攝影機原始位置
        cameraTransform.localPosition = originalCameraPosition;
    }

    private void PlaySound(AudioClip clip)
    {
        if (clip != null && audioSource != null)
        {
            audioSource.volume = soundVolume; // 設定音效音量
            audioSource.PlayOneShot(clip); // 播放指定音效
        }
    }
}
