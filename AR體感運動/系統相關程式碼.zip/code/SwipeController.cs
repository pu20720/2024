using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SwipeController : MonoBehaviour
{
    [SerializeField] int maxPage;
    int currentPage = 1;
    Vector3 targetPos;
    [SerializeField] Vector3 pageStep;
    [SerializeField] RectTransform levelPagesRect;
    [SerializeField] float tweenTime;
    [SerializeField] LeanTweenType tweenType;

    [SerializeField] Image[] barImage;
    [SerializeField] Sprite barClosed, barOpen;
    [SerializeField] Button previousBtn, nextBtn;

    private Kinect_menu kinectDetector;
    [SerializeField] Transform targetCameraPosition;
    private bool isFunctionEnabled = false;

    private void Awake()
    {
        currentPage = 1;
        targetPos = levelPagesRect.localPosition;
        UpdateBar();
        UpdateArrowButton();

        kinectDetector = FindObjectOfType<Kinect_menu>();
    }

    private void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        // 在每次場景加載完成後重置 SwipeController 的狀態
        ResetSwipeControllerState();
        
        // 恢復當前頁面根據模式
        if (scene.name == "Main")
        {
            // 獲取並應用保存的模式頁面
            int lastMode = PlayerPrefs.GetInt("LastMode", 1);
            currentPage = Mathf.Clamp(lastMode, 1, maxPage); // 確保頁面合法
            targetPos = levelPagesRect.localPosition + (pageStep * (currentPage - 1));
            levelPagesRect.localPosition = targetPos; // 強制同步位置
            UpdateBar();
            UpdateArrowButton();
            Debug.Log($"恢復至模式 {currentPage}");

            // 將模式重置為 mode1
            //PlayerPrefs.SetInt("LastMode", 1);
        }
    }

    private void ResetSwipeControllerState()
    {
        currentPage = 1;
        targetPos = levelPagesRect.localPosition;
        levelPagesRect.localPosition = targetPos; // 確保位置同步
        UpdateBar();
        UpdateArrowButton();
        isFunctionEnabled = false;
        Debug.Log("SwipeController 狀態已重置");
    }

    private void Update()
    {
        if (isFunctionEnabled == false && Camera.main.transform.position == targetCameraPosition.position)
        {
            isFunctionEnabled = true;
            kinectDetector.ResetGestureDetection();  // 重置手勢偵測
            Debug.Log("功能已啟用");
        }

        if (isFunctionEnabled)
        {
            if (kinectDetector.GetAndResetSwipeLeft())
            {
                Previous();
            }
            else if (kinectDetector.GetAndResetSwipeRight())
            {
                Next();
            }
            else if (kinectDetector.GetAndResetHeadHold())
            {
                SelectMenu();
            }
        }
    }

    public void Next()
    {
        if (currentPage < maxPage)
        {
            currentPage++;
            targetPos += pageStep;
            MovePage();
        }
    }

    public void Previous()
    {
        if (currentPage > 1)
        {
            currentPage--;
            targetPos -= pageStep;
            MovePage();
        }
    }

    void MovePage()
    {
        levelPagesRect.LeanMoveLocal(targetPos, tweenTime).setEase(tweenType);
        UpdateBar();
        UpdateArrowButton();
    }

    void UpdateBar()
    {
        foreach (var item in barImage)
        {
            item.sprite = barClosed;
        }
        barImage[currentPage - 1].sprite = barOpen;
    }

    void UpdateArrowButton()
    {
        nextBtn.interactable = true;
        previousBtn.interactable = true;
        if (currentPage == 1) previousBtn.interactable = false;
        else if (currentPage == maxPage) nextBtn.interactable = false;
    }

    // 選擇當前菜單的邏輯，根據當前頁面進入對應的模式
    void SelectMenu()
    {
        Debug.Log("選擇當前菜單: " + currentPage);

        switch (currentPage)
        {
            case 1:
                SceneManager.LoadScene("Mode1"); // 加載 Mode1 場景
                break;
            case 2:
                SceneManager.LoadScene("Mode2"); // 加載 Mode2 場景
                break;
            case 3:
                SceneManager.LoadScene("Mode3"); // 加載 Mode3 場景
                break;
            default:
                Debug.LogWarning("無法識別的菜單頁面");
                break;
        }
    }
}