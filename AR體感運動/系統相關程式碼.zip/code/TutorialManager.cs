using UnityEngine;
using TMPro;
using System.Collections;

public class TutorialManager : MonoBehaviour
{
    public GameObject selectedCameraObject; // 可指定鏡頭的GameObject
    private Camera mainCamera; // 主鏡頭
    public float shakeMagnitude = 0.5f; // 晃動幅度
    public float shakeDuration = 1.0f; // 晃動持續時間
    private Vector3 originalCameraPosition; // 鏡頭的初始位置
    private bool isShaking = false; // 檢查是否正在震動中

    public GameObject countdownPanel;
    public GameObject Panel;
    public PunchingBag punchingBag;
    public TMP_Text instructionText;
    public TMP_Text freePlayText;

    public GameObject headHighlight;  // 頭部光圈
    public GameObject bodyHighlight; // 身體光圈
    public GameObject leftHandHighlight; // 左手光圈
    public GameObject rightHandHighlight; // 右手光圈

    public int headHitsRequired = 5;
    public int bodyHitsRequired = 5;
    public int handHitsRequired = 5;

    private int currentHeadHits = 0;
    private int currentBodyHits = 0;
    private int currentHandHits = 0;

    private enum TutorialState { Head, Body, Hand, Completed }
    private TutorialState currentState = TutorialState.Head;

    private bool isFreePlay = false;
    private int totalScore = 0;

    // 冷卻時間設置
    public float hitCooldown = 1.0f;
    private float lastHeadHitTime = -1f;
    private float lastBodyHitTime = -1f;
    private float lastHandHitTime = -1f;
    public TMP_Text countdownText;
    public int countdownTime = 5;
    //private bool isCountdownActive = true;

    // 是否正在倒數
    public bool isCountingDown = true; 

    //private bool isKinectEnabled = false;  // Kinect 輸入是否啟用

    void Start()
    {
        mainCamera = selectedCameraObject.GetComponent<Camera>(); // 取得鏡頭組件
        if (mainCamera == null)
        {
            Debug.LogError("鏡頭未正確設置，請確認選擇的物件有 Camera 組件。");
        }

        originalCameraPosition = mainCamera.transform.position; // 保存鏡頭的初始位置

        StartCoroutine(StartCountdown()); // 開始倒數
        freePlayText.gameObject.SetActive(false);
        instructionText.gameObject.SetActive(false); // 暫時隱藏教學文本
        countdownText.gameObject.SetActive(true); // 顯示倒數文本
        Panel.SetActive(false);
        headHighlight.gameObject.SetActive(false);
        bodyHighlight.gameObject.SetActive(false);
        leftHandHighlight.gameObject.SetActive(false);
        rightHandHighlight.gameObject.SetActive(false);
    }

    void Update()
    {
        CheckProgress();
    }

    void UpdateInstructionText()
    {
        switch (currentState)
        {
            case TutorialState.Head:
                instructionText.text = $"擊打頭部 {headHitsRequired} 次，進度: {currentHeadHits}/{headHitsRequired}";
                break;
            case TutorialState.Body:
                instructionText.text = $"擊打身體 {bodyHitsRequired} 次，進度: {currentBodyHits}/{bodyHitsRequired}";
                break;
            case TutorialState.Hand:
                instructionText.text = $"擊打手部 {handHitsRequired} 次，進度: {currentHandHits}/{handHitsRequired}";
                break;
            case TutorialState.Completed:
                instructionText.text = "教學完成！你現在可以自由操作。";
                EnterFreePlayMode();
                break;
        }

        UpdateHighlights(); // 更新光圈顯示
    }

    void CheckProgress()
    {
        switch (currentState)
        {
            case TutorialState.Head:
                if (currentHeadHits >= headHitsRequired)
                {
                    currentState = TutorialState.Body;
                    UpdateInstructionText();
                }
                break;
            case TutorialState.Body:
                if (currentBodyHits >= bodyHitsRequired)
                {
                    currentState = TutorialState.Hand;
                    UpdateInstructionText();
                    punchingBag.PlayDefense(); // 進入手部狀態時播放防禦動作
                }
                break;
            case TutorialState.Hand:
                if (currentHandHits >= handHitsRequired)
                {
                    currentState = TutorialState.Completed;
                    UpdateInstructionText();
                    punchingBag.PlayIdle(); // 完成手部部分後恢復靜止狀態
                }
                break;
        }
    }

    public void RegisterHit(string bodyPart)
    {
        // 在倒數期間禁止所有操作
        if (isCountingDown)
        {
            return; // 直接返回，不進行任何操作
        }

        // 當 Kinects 偵測到擊中目標時
        if (bodyPart == "Head" || bodyPart == "Body" || bodyPart == "Hand")
        {
            StartCoroutine(ScreenShake()); // 當偵測到標籤被打到後，開始震動螢幕
        }

        float currentTime = Time.time;

        if (!isFreePlay)
        {
            // 教學模式期間
            switch (bodyPart)
            {
                case "Head":
                    if (currentState == TutorialState.Head && currentTime - lastHeadHitTime >= hitCooldown)
                    {
                        currentHeadHits++;
                        lastHeadHitTime = currentTime;
                        UpdateInstructionText();
                        Debug.Log("Hit registered for: Head");
                        return;
                    }
                    break;
                case "Body":
                    if (currentState == TutorialState.Body && currentTime - lastBodyHitTime >= hitCooldown)
                    {
                        currentBodyHits++;
                        lastBodyHitTime = currentTime;
                        UpdateInstructionText();
                        Debug.Log("Hit registered for: Body");
                        return;
                    }
                    break;
                case "Hand":
                    if (currentState == TutorialState.Hand && currentTime - lastHandHitTime >= hitCooldown)
                    {
                        currentHandHits++;
                        lastHandHitTime = currentTime;
                        UpdateInstructionText();
                        Debug.Log("Hit registered for: Hand");
                        return;
                    }
                    break;
            }
        }
        else
        {
            // 自由遊玩模式期間
            int points = 0;
            switch (bodyPart)
            {
                case "Head":
                    if (currentTime - lastHeadHitTime >= hitCooldown)
                    {
                        points = 3;
                        lastHeadHitTime = currentTime;
                        Debug.Log("Hit registered for: Head");
                    }
                    break;
                case "Body":
                    if (currentTime - lastBodyHitTime >= hitCooldown)
                    {
                        points = 2;
                        lastBodyHitTime = currentTime;
                        Debug.Log("Hit registered for: Body");
                    }
                    break;
                case "Hand":
                    if (currentTime - lastHandHitTime >= hitCooldown)
                    {
                        points = 0;
                        lastHandHitTime = currentTime;
                        Debug.Log("Hit registered for: Hand");
                    }
                    break;
                default:
                    Debug.LogWarning("未知的部位: " + bodyPart);
                    break;
            }

            totalScore += points;
            freePlayText.text = $"擊打: {bodyPart}\n分數: {points}\n總分: {totalScore}";
            freePlayText.gameObject.SetActive(true);
        }
    }

    void EnterFreePlayMode()
    {
        isFreePlay = true;
        instructionText.gameObject.SetActive(false);
        freePlayText.gameObject.SetActive(true);
        freePlayText.text = "自由遊玩模式開始！\n擊打任意部位以獲得分數。";
        UpdateHighlights(); // 關閉所有光圈
    }

    IEnumerator StartCountdown()
    {
        int remainingTime = countdownTime;

        isCountingDown = true; // 開始倒數，禁用 Kinect 輸入
        Time.timeScale = 0; // 暫停遊戲時間

        while (remainingTime > 0)
        {
            countdownText.text = $"開始前倒數: {remainingTime}";
            yield return new WaitForSecondsRealtime(1); // 使用 WaitForSecondsRealtime 以免受時間縮放影響
            remainingTime--;
        }

        countdownText.gameObject.SetActive(false); // 隱藏倒數文本
        countdownPanel.SetActive(false);          // 隱藏倒數面板
        instructionText.gameObject.SetActive(true); // 顯示教學文本
        Panel.SetActive(true);
        UpdateInstructionText(); // 初始化教學文本

        isCountingDown = false; // 倒數結束後允許動作輸入
        Time.timeScale = 1; // 恢復遊戲時間
    }

    // 屏幕震動
    IEnumerator ScreenShake()
    {
        if (isShaking) yield break;

        isShaking = true;
        float elapsed = 0.0f;

        while (elapsed < shakeDuration)
        {
            Vector3 randomOffset = Random.insideUnitSphere * shakeMagnitude;
            mainCamera.transform.position = originalCameraPosition + randomOffset;

            elapsed += Time.deltaTime;
            yield return null;
        }

        mainCamera.transform.position = originalCameraPosition;
        isShaking = false;
    }

    void UpdateHighlights()
    {
        headHighlight.SetActive(currentState == TutorialState.Head);
        bodyHighlight.SetActive(currentState == TutorialState.Body);
        leftHandHighlight.SetActive(currentState == TutorialState.Hand);
        rightHandHighlight.SetActive(currentState == TutorialState.Hand);
    }
    // 確保退出時正確釋放資源，恢復時間
    private void OnApplicationQuit()
    {
        Time.timeScale = 1; // 恢復遊戲時間
    }
}
