using UnityEngine;
using UnityEngine.UI;

public class CloseApplication : MonoBehaviour
{
    public Button closeButton; // 關閉按鈕

    void Start()
    {
        // 註冊按鈕點擊事件
        closeButton.onClick.AddListener(OnCloseButtonClick);
    }

    void OnCloseButtonClick()
    {
        // 在建置後的應用程式中，這行代碼會退出應用
        Application.Quit();

        // 在編輯器模式下，這行代碼會停止播放模式
        #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
        #endif
    }
}
