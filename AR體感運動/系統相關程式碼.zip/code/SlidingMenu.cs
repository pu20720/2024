using UnityEngine;
using UnityEngine.UI;

public class SlidingMenu : MonoBehaviour
{
    public RectTransform menuPanel; // 菜单Panel
    public float slideSpeed = 10f;  // 滑动速度
    public bool isOpen = false;     // 菜单是否打开

    private Vector2 closedPosition; // 菜单关闭时的位置
    private Vector2 openPosition;   // 菜单打开时的位置

    void Start()
    {
        // 设置菜单的打开和关闭位置
        closedPosition = menuPanel.anchoredPosition;
        openPosition = new Vector2(0, menuPanel.anchoredPosition.y);
    }

    void Update()
    {
        // 根据菜单状态平滑移动菜单
        if (isOpen)
        {
            menuPanel.anchoredPosition = Vector2.Lerp(menuPanel.anchoredPosition, openPosition, Time.deltaTime * slideSpeed);
        }
        else
        {
            menuPanel.anchoredPosition = Vector2.Lerp(menuPanel.anchoredPosition, closedPosition, Time.deltaTime * slideSpeed);
        }
    }

    // 切换菜单状态
    public void ToggleMenu()
    {
        isOpen = !isOpen;
    }
}
