from baselines.offpolicy.algorithms.mqmix.algorithm.mQMixPolicy import M_QMixPolicy


class M_VDNPolicy(M_QMixPolicy):
    """See parent class."""

    pass
