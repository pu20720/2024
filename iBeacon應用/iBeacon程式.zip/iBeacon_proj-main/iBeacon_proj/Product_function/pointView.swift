//
//  pointView.swift
//  test
//
//  Created by 林京緯 on 2024/5/4.
//

import SwiftUI

struct pointView: View {
    var body: some View {
        Text("點數頁面")
    }
}

#Preview {
    pointView()
}
