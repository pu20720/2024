//
//  giftRecord.swift
//  iBeacon_proj
//
//  Created by 林京緯 on 2024/9/11.
//

import SwiftUI

struct giftRecord: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    giftRecord()
}
