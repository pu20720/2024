from dronekit import connect, VehicleMode
import time

vehicle = connect('/dev/ttyACM0', wait_ready=True, baud=57600)

vehicle.mode = VehicleMode("GUIDED_NOGPS")

def set_servo_pwm(servo_n, pwm_value):
    msg = vehicle.message_factory.command_long_encode(
        0, 0,
        183,
        0,
        servo_n,
        pwm_value,
        0, 0, 0, 0, 0)
    vehicle.send_mavlink(msg)

set_servo_pwm(9, 1065) #1065 1700

time.sleep(2)

vehicle.close()

