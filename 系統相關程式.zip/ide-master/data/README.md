Chinook database was download from here: https://www.sqlitetutorial.net/sqlite-sample-database
