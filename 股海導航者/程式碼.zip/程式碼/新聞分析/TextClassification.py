import json
import torch
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, recall_score, precision_score, f1_score
from transformers import TrainingArguments, Trainer
from transformers import BertTokenizerFast, BertForSequenceClassification
from transformers import EarlyStoppingCallback

tokenizer = BertTokenizerFast.from_pretrained('ckiplab/bert-base-chinese')
model = BertForSequenceClassification.from_pretrained('ckiplab/bert-base-chinese')

class Dataset(torch.utils.data.Dataset):
  def __init__(self, encodings, labels=None):
    self.encodings = encodings
    self.labels = labels

  def __getitem__(self, idx):
    item = {k: torch.tensor(v[idx]) for k, v in self.encodings.items()}
    if self.labels:
      item["labels"] = torch.tensor(self.labels[idx])
    return item

  def __len__(self):
    return len(self.encodings["input_ids"])


content=[]
def read_data():
  with open('data.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

  documents = [" ".join(item["Content"]) for item in data]

  return documents

content = read_data()
print(content)

train_encodings = tokenizer(content, truncation=True, padding=True, max_length=256)

model_path = "/content/drive/MyDrive/DeepLearning/output2/checkpoint-150"
model = BertForSequenceClassification.from_pretrained(model_path, num_labels=2)

args=TrainingArguments(
  output_dir='result',
  report_to=[],
)
test_trainer = Trainer(
    model=model,
    args=args,
)

raw_pred, _, _ = test_trainer.predict(test_dataset)
y_pred = np.argmax(raw_pred, axis=1)

y_pred_transformed = np.where(y_pred == 0, -1, 1)

print(y_pred_transformed)
