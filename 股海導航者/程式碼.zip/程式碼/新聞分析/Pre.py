import json
import torch
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, recall_score, precision_score, f1_score
from transformers import TrainingArguments, Trainer
from transformers import BertTokenizerFast, BertForSequenceClassification
from transformers import EarlyStoppingCallback
from sklearn.model_selection import train_test_split
from datasets import Dataset, DatasetDict

tokenizer = BertTokenizerFast.from_pretrained('ckiplab/bert-base-chinese')
model = BertForSequenceClassification.from_pretrained('ckiplab/bert-base-chinese')

def read_data(test_size=0.2):

  with open('data.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

  documents = [" ".join(item["RelevantContent"]) for item in data]
  labels = [item["Labeling"] for item in data]

  return train_test_split(documents, labels, test_size=test_size)

(train_texts, valid_texts, train_labels, valid_labels) = read_data()

train_encodings = tokenizer(train_texts, truncation=True, padding=True, max_length=512)
valid_encodings = tokenizer(valid_texts, truncation=True, padding=True, max_length=512)

class Dataset(torch.utils.data.Dataset):
  def __init__(self, encodings, labels):
    self.encodings = encodings
    self.labels = labels

  def __getitem__(self, idx):
    item = {k: torch.tensor(v[idx]) for k, v in self.encodings.items()}
    item["labels"] = torch.tensor([self.labels[idx]])
    return item

  def __len__(self):
    return len(self.encodings["input_ids"])

train_dataset = Dataset(train_encodings, train_labels)
valid_dataset = Dataset(valid_encodings, valid_labels)

def compute_metrics(p):
  pred, labels = p
  pred = np.argmax(pred, axis=1)

  accuracy = accuracy_score(y_true=labels, y_pred=pred)
  recall = recall_score(y_true=labels, y_pred=pred)
  precision = precision_score(y_true=labels, y_pred=pred)
  f1 = f1_score(y_true=labels, y_pred=pred)
  return {"accuracy": accuracy, "precision": precision, "recall": recall, "f1": f1}

args = TrainingArguments(
    output_dir="/content/drive/MyDrive/DeepLearning/lastopt",
    eval_strategy="steps",
    eval_steps=100,
    per_device_train_batch_size=16,
    per_device_eval_batch_size=16,
    num_train_epochs=5,
    seed=0,
    load_best_model_at_end=True,
    logging_steps=200,
    learning_rate=2e-5,
    weight_decay=0.01,
    report_to=[],
)
trainer = Trainer(
    model=model,
    args=args,
    train_dataset=train_dataset,
    eval_dataset=valid_dataset,
    compute_metrics=compute_metrics,
    callbacks=[EarlyStoppingCallback(early_stopping_patience=3)],
)

trainer.train()

eval_results = trainer.evaluate()
print(eval_results)