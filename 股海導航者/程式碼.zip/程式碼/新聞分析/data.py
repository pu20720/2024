from ckip_transformers import __version__
from ckip_transformers.nlp import CkipWordSegmenter, CkipPosTagger, CkipNerChunker
import json

ws_driver = CkipWordSegmenter(model="bert-base", device=-1)
pos_driver = CkipPosTagger(model="bert-base", device=-1)
ner_driver = CkipNerChunker(model="bert-base", device=-1)

def clean(sentence_ws, sentence_pos):
  short_with_pos = []
  short_sentence = []
  stop_pos = set(['Nep', 'Nh', 'Nb'])
  for word_ws, word_pos in zip(sentence_ws, sentence_pos):
    is_N_or_V = word_pos.startswith("V") or word_pos.startswith("N")
    is_not_stop_pos = word_pos not in stop_pos
    is_not_one_charactor = not (len(word_ws) == 1)
    if is_N_or_V and is_not_stop_pos and is_not_one_charactor:
      short_with_pos.append(f"{word_ws}({word_pos})")
      short_sentence.append(f"{word_ws}")
  return (" ".join(short_sentence), " ".join(short_with_pos))

def main():
    with open('1.json', 'r', encoding='utf-8') as f:
      data = json.load(f)

    for item in data:
      content = item["RelevantContent"]
      short_contents = []
      ws = ws_driver(content)
      pos = pos_driver(ws)
      ner = ner_driver(content)
      for sentence, sentence_ws, sentence_pos, sentence_ner in zip(content, ws, pos, ner):
          (short, res) = clean(sentence_ws, sentence_pos)
          short_contents.append(short)
      item["RelevantContent"] = short_contents

    with open('processed_file.json', 'w', encoding='utf-8') as f:
      json.dump(data, f, ensure_ascii=False, indent=4)

if __name__ == "__main__":
    main()