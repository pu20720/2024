import numpy as np
import pandas as pd
import yfinance as yf
import math
import json
import os
from google.colab import drive
from datetime import timedelta
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, LSTM, Dropout, GRU
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.losses import MeanAbsoluteError

# 掛載 Google Drive
drive.mount('/content/drive')

# 設定 Google Drive 中的模型保存資料夾路徑
gdrive_model_dir = '/content/drive/MyDrive/模型保存/models'
os.makedirs(gdrive_model_dir, exist_ok=True)

# 定義股票代碼和公司名稱
stock_codes = {
    '2330.TW': '台積電',
    '2382.TW': '廣達',
    '2454.TW': '聯發科',
    '3661.TW': '世芯',
    '2308.TW': '台達電'
}

def get_future_dates(start_date, num_days):
    future_dates = []
    current_date = start_date
    while len(future_dates) < num_days:
        if current_date.weekday() < 5:  # 只選擇工作日
            future_dates.append(current_date)
        current_date += timedelta(days=1)
    return future_dates

def calculate_features(data):
    # 計算 EMA 和 RSI
    data['EMA_20'] = data['Close'].ewm(span=20, adjust=False).mean()
    delta = data['Close'].diff(1)
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss
    data['RSI'] = 100 - (100 / (1 + rs))
    data['Volatility'] = data['Close'].pct_change().rolling(window=5).std()
    data['Daily_Change'] = data['Close'].pct_change()
    data.fillna(0, inplace=True)
    return data

def build_model(input_shape):
    model = Sequential([
        LSTM(128, return_sequences=True, input_shape=input_shape),
        Dropout(0.3),
        GRU(64, return_sequences=True),
        Dropout(0.3),
        LSTM(64, return_sequences=False),
        Dense(32, activation='relu'),
        Dense(1)
    ])
    model.compile(optimizer=Adam(learning_rate=0.0005), loss=MeanAbsoluteError())
    return model

def run_prediction():
    start_date = '2014-01-01'
    end_date = '2024-10-1'  # 擷取到09/30
    predictions = {}
    data_frames = {}

    for code, name in stock_codes.items():
        df = yf.download(code, start=start_date, end=end_date)
        df = calculate_features(df)
        data_frames[code] = df[['Open', 'Close', 'High', 'Low', 'Volume', 'EMA_20', 'RSI', 'Volatility', 'Daily_Change']]
        print(f"{name} data loaded and features added.")

    for code, name in stock_codes.items():
        model_path = f"{gdrive_model_dir}/{name}_model.h5"

        # 檢查模型是否已存在
        if os.path.exists(model_path):
            print(f"{name} 的模型已存在，跳過訓練階段.")
            model = load_model(model_path)
        else:
            print(f"\n正在為 {name} ({code}) 訓練模型...")

            company_data = data_frames[code].values
            training_data_len = math.ceil(len(company_data) * 0.85)
            scaler = MinMaxScaler(feature_range=(0, 1))
            scaled_data = scaler.fit_transform(company_data)

            train_data = scaled_data[0:training_data_len, :]
            x_train, y_train = [], []
            for i in range(60, len(train_data)):
                x_train.append(train_data[i - 60:i, :])
                y_train.append(train_data[i, 1])  # 使用 'Close' 作為 y_train
            x_train, y_train = np.array(x_train), np.array(y_train)

            model = build_model((x_train.shape[1], x_train.shape[2]))
            early_stop = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
            model.fit(x_train, y_train, batch_size=32, epochs=80, validation_split=0.2, callbacks=[early_stop], verbose=0)

            # 保存模型到 Google Drive
            model.save(model_path)
            print(f"{name} 的模型已保存到 Google Drive.")

        # 預測階段，使用新聞情緒數據來調整預測價格
        last_date = data_frames[code].index[-1]
        next_date = get_future_dates(last_date + timedelta(days=1), 1)[0]

        # 預測下一天的收盤價
        company_data = data_frames[code].values  # 新增這行，將該公司的數據指派給 company_data
        recent_data = data_frames[code].tail(60).values  # 取最後 60 天的數據
        scaler = MinMaxScaler(feature_range=(0, 1))
        scaled_recent_data = scaler.fit_transform(recent_data)
        x_input = scaled_recent_data.reshape((1, 60, recent_data.shape[1]))
        predicted_price = model.predict(x_input)[0][0]
        predicted_price = scaler.inverse_transform([[0, predicted_price] + [0] * (recent_data.shape[1] - 2)])[0][1]  # 還原縮放的 'Close' 值

        # 讀取新聞情緒標籤並根據情緒調整預測價格
        with open('a.json', 'r', encoding='utf-8') as file:
            news_data = json.load(file)

        # 根據股票代碼從新聞數據中找到對應的情緒標籤
        news_label = next((item['label'] for item in news_data if item['stock_code'] == code), 0)

        # 根據情緒調整預測價格
        tprice = company_data[-2, 1]  # 取得最近一天的收盤價
        print(f"{name} 的前一日收盤價: {tprice:.2f}")

        for i in range(1):  # 此處設定為只調整下一日的預測價格
            if news_label == 1:
                predicted_price = max(predicted_price, tprice * 1.02)
            elif news_label == -1:
                predicted_price = min(predicted_price, tprice * 0.99)

        predictions[name] = (next_date, predicted_price)
        print(f"{name} 的調整後預測收盤價為: {predicted_price:.2f}（日期: {next_date}）")

    print("\n未來一天每家公司的預測收盤價:")
    for name, (date, price) in predictions.items():
        formatted_date = date.strftime('%Y-%m-%d')  # 僅保留年月日
        print(f"{name}: 日期: {formatted_date}, 預測收盤價: {price:.2f}")

# 執行預測
run_prediction()


