需要安裝以下python套件:
yfinance, pandas, pymongo, datetime, requests, numpy, selenium, webdriver-manager, bs4, flask, werkzeug.security, dateutil

電腦需安裝mongodb

本系統使用說明:
 1.topics_app/py/req_daily 裡的檔案需要每天執行，可以設定讓這些檔案每天自動執行
 2.topics_app/py/req 裡有monthly前綴的檔案需要每個月執行 req_capital.py只需要執行一次
 3.每次使用系統時須將topics_app/app/app.py開著並在瀏覽器網址輸入127.0.0.1來開啟