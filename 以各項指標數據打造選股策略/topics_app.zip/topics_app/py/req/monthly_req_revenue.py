import requests
from bs4 import BeautifulSoup
from pymongo import MongoClient
from datetime import datetime

current_year = datetime.now().year
current_month = datetime.now().month

taiwan_year = current_year - 1911

formatted_date = f"{taiwan_year}_{current_month:02d}"

url = f"https://mops.twse.com.tw/nas/t21/sii/t21sc03_{formatted_date}_0.html"

url_parts = url.split('_')
year_month = url_parts[1] + '/' + url_parts[2].split('.')[0]

response = requests.get(url)
response.encoding = 'big5'

if response.status_code != 200:
    print(f"无法访问网页，状态码：{response.status_code}")
    exit()

soup = BeautifulSoup(response.text, 'html.parser')

big_tables = soup.find_all('table')

data_list = []
count = 0
ct = 10000

for big_table in big_tables:
    small_tables = big_table.find_all('table')

    for small_table in small_tables:
        tiny_tables = small_table.find_all('table')

        for tiny_table in tiny_tables:
            rows = tiny_table.find_all('tr')

            if len(rows) > 3:
                for row in rows[2:-1]:
                    cells = row.find_all('td')
                    if len(cells) >= 3:
                        company_code = cells[0].get_text(strip=True)
                        company_name = cells[1].get_text(strip=True)
                        monthly_revenue = cells[2].get_text(strip=True)
                        growth_rate = cells[5].get_text(strip=True)

                        if "合計" in company_code or not company_code.isdigit():
                            continue
                        if "全部國內上市公司合計" in company_code or not company_code.isdigit():
                            continue

                        monthly_revenue = int(monthly_revenue.replace(',', ''))

                        data_list.append({
                            'stock_code': company_code,
                            'stock_name': company_name,
                            'month': year_month,
                            'revenue': monthly_revenue,
                            'growth_rate': growth_rate
                        })

                        count += 1
                        if count >= ct:
                            break

            if count >= ct:
                break
        if count >= ct:
            break
    if count >= ct:
        break


client = MongoClient('mongodb://localhost:27017/')
db = client['test']
collection = db['revenue']

for data in data_list:
    existing_record = collection.find_one({
        'stock_code': data['stock_code'],
        'month': data['month']
    })

    if existing_record:
        collection.update_one(
            {'_id': existing_record['_id']},
            {'$set': {
                'revenue': data['revenue'],
                'growth_rate': data['growth_rate']
            }}
        )
    else:
        collection.insert_one(data)

print(f"成功保存或更新 {len(data_list)} 條紀錄到 MongoDB。")
