import requests
import pymongo
from datetime import datetime
import time

today_date = datetime.now().strftime('%Y%m%d')

client = pymongo.MongoClient("mongodb://localhost:27017/")
db = client["test"]
collection = db["market_index"]

try:
    url = f"https://www.twse.com.tw/exchangeReport/MI_INDEX?response=json&date={today_date}&type=IND"
    response = requests.get(url)
    data = response.json()

    if "data1" not in data or not data["data1"]:
        print(f'{today_date} 無資料，跳過。')
    else:
        value = data["data1"][1][1]
        value = value.replace(',', '')
        value_int = int(float(value))

        record = {"date": today_date, "value": value_int}
        collection.insert_one(record)
        print(f'{today_date} 股票指數獲取成功！')
except Exception as e:
    print(f'{today_date} 獲取資料出錯：{e}')
