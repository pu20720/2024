from pymongo import MongoClient
import pandas as pd
from pymongo import UpdateOne

client = MongoClient('mongodb://localhost:27017/')
db = client['test']
collection = db['price']

def get_stock_data(stock_code):
    cursor = collection.find({"code": stock_code}, {"_id": 0, "date": 1, "close": 1})
    data = list(cursor)
    df = pd.DataFrame(data)
    df['date'] = pd.to_datetime(df['date'], format='%Y-%m-%d')
    df = df.sort_values(by='date')
    return df

def calculate_rsi(df, period=14):
    df['price_diff'] = df['close'].diff()
    df['gain'] = df['price_diff'].apply(lambda x: x if x > 0 else 0)
    df['loss'] = df['price_diff'].apply(lambda x: -x if x < 0 else 0)
    df['avg_gain'] = df['gain'].rolling(window=period, min_periods=1).mean()
    df['avg_loss'] = df['loss'].rolling(window=period, min_periods=1).mean()
    df['RS'] = df['avg_gain'] / df['avg_loss']
    df['RSI'] = 100 - (100 / (1 + df['RS']))
    return df[['date', 'RSI']]

def update_stock_with_rsi(stock_code, df):
    operations = []
    for index, row in df.iterrows():
        rsi_value = row['RSI']
        if pd.isna(rsi_value):
            rsi_value = 0
        else:
            rsi_value = round(rsi_value, 2)
        operations.append(UpdateOne(
            {"code": stock_code, "date": row['date'].strftime('%Y-%m-%d')},
            {"$set": {
                "RSI": rsi_value
            }},
            upsert=True
        ))
    if operations:
        collection.bulk_write(operations)

def process_all_stocks(batch_size=100):
    stock_codes = collection.distinct("code")
    for i in range(0, len(stock_codes), batch_size):
        batch = stock_codes[i:i + batch_size]
        for stock_code in batch:
            print(f"處理股票: {stock_code}")
            stock_data = get_stock_data(stock_code)
            if not stock_data.empty:
                rsi_result = calculate_rsi(stock_data)
                update_stock_with_rsi(stock_code, rsi_result)

process_all_stocks()
