from pymongo import MongoClient
import requests
from datetime import datetime

client = MongoClient('mongodb://localhost:27017/')
db = client['test']
collection = db['price']

current_date = datetime.now()
query_date = current_date.strftime("%Y-%m-%d")
twse_date = current_date.strftime("%Y%m%d")

print(f"Fetching data for {query_date}...")

url = f"https://wwwc.twse.com.tw/rwd/zh/fund/T86?date={twse_date}&selectType=ALLBUT0999&response=json"
response = requests.get(url)

if response.status_code == 200:
    data = response.json()

    if data.get("stat") == "很抱歉，沒有符合條件的資料!":
        print(f"No data available for {query_date}, skipping...")
    else:
        docs = collection.find({"date": query_date})

        for doc in docs:
            code = doc['code']

            for entry in data['data']:
                if entry[0] == code:
                    foreign = int(entry[4].replace(",", ""))
                    investment = int(entry[10].replace(",", ""))
                    dealer = int(entry[11].replace(",", ""))
                    investors = int(entry[-1].replace(",", ""))

                    collection.update_one(
                        {"_id": doc['_id']},
                        {"$set": {
                            "foreign": foreign,
                            "investment": investment,
                            "dealer": dealer,
                            "investors": investors
                        }}
                    )

        print(f"{query_date} completed")
else:
    print(f"Failed to fetch data from the URL for {query_date}, status code: {response.status_code}")

print("Data fetching completed.")
