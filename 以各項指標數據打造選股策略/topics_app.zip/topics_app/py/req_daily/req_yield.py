from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.action_chains import ActionChains
import time
from pymongo import MongoClient
from datetime import datetime

options = Options()
options.headless = False
options.add_argument("--disable-gpu")
options.add_argument("--no-sandbox")

service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=options)

client = MongoClient('mongodb://localhost:27017/') 
db = client['test'] 
collection = db['yield'] 

def close_advertisement():
    try:
        time.sleep(10)
        close_button = driver.find_element(By.CLASS_NAME, "popov-ad__close")
        close_button.click()
        print("已關閉廣告。")
    except Exception as e:
        print(f"未找到廣告關閉按鈕或關閉廣告失敗: {e}")

def fetch_data(url, is_first_page=False):
    driver.get(url)
    if is_first_page:
        close_advertisement()
        time.sleep(5)
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    time.sleep(3)
    all_table_data = []
    tables = driver.find_elements(By.TAG_NAME, 'table')
    for table in tables:
        tbody = table.find_element(By.TAG_NAME, 'tbody')
        rows = tbody.find_elements(By.TAG_NAME, 'tr')
        table_data = []
        for row in rows:
            cols = row.find_elements(By.TAG_NAME, 'td')
            if len(cols) > 5:
                stock_code = cols[1].text.strip()
                stock_name = cols[2].text.strip()
                dividend_yield = cols[4].text.strip()
                table_data.append((stock_code, stock_name, dividend_yield))
        print(f"抓取到的表格數據（共{len(table_data)}條）:")
        for entry in table_data:
            print(entry)
        all_table_data.extend(table_data)
    return all_table_data

def save_to_mongodb(data):
    today = datetime.now().strftime("%Y-%m-%d")
    for entry in data:
        stock_code, stock_name, dividend_yield = entry
        if stock_code.isdigit() and len(stock_code) == 4:
            document = {
                "stock_code": stock_code,
                "stock_name": stock_name,
                "yield": dividend_yield,
                "date": today
            }
            collection.insert_one(document)
    print("所有數據已保存到 MongoDB。")

def main():
    page = 1
    all_data = []
    print(f"正在抓取第 {page} 頁數據...")
    first_page_data = fetch_data("https://www.wantgoo.com/stock/dividend-yield?market=Listed", is_first_page=True)
    if first_page_data:
        all_data.extend(first_page_data)
    page = 2
    while True:
        next_page_url = f"https://www.wantgoo.com/stock/dividend-yield?page={page}&market=Listed"
        print(f"正在抓取第 {page} 頁數據...")
        page_data = fetch_data(next_page_url)
        if page_data:
            all_data.extend(page_data)
            page += 1
            time.sleep(5)
        else:
            print(f"第 {page} 頁沒有數據，停止抓取。")
            break
    save_to_mongodb(all_data)
    print("\n所有抓取到的數據:")
    for item in all_data:
        print(item)
    driver.quit()

if __name__ == "__main__":
    main()
