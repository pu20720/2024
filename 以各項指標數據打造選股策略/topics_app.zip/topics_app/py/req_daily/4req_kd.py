from pymongo import MongoClient
import pandas as pd
from pymongo import UpdateOne
import numpy as np

client = MongoClient('mongodb://localhost:27017/')
db = client['test']
collection = db['price']

def get_stock_data(stock_code):
    cursor = collection.find({"code": stock_code}, {"_id": 0, "date": 1, "close": 1, "high": 1, "low": 1})
    data = list(cursor)
    df = pd.DataFrame(data)
    df['date'] = pd.to_datetime(df['date'], format='%Y-%m-%d')
    df = df.sort_values(by='date')
    return df

def calculate_kd(df, period=9):
    df['low_min'] = df['low'].rolling(window=period, min_periods=1).min()
    df['high_max'] = df['high'].rolling(window=period, min_periods=1).max()
    df['denominator'] = df['high_max'] - df['low_min']
    df['RSV'] = np.where(
        df['denominator'] != 0,
        (df['close'] - df['low_min']) / df['denominator'] * 100,
        50
    )
    df['RSV'] = df['RSV'].clip(lower=0, upper=100)
    df['RSV'] = df['RSV'].fillna(50)
    df['K'] = 50.0
    df['D'] = 50.0
    for i in range(1, len(df)):
        df.loc[df.index[i], 'K'] = ((2/3) * df.loc[df.index[i-1], 'K']) + ((1/3) * df.loc[df.index[i], 'RSV'])
        df.loc[df.index[i], 'D'] = ((2/3) * df.loc[df.index[i-1], 'D']) + ((1/3) * df.loc[df.index[i], 'K'])
    df['K'] = df['K'].clip(lower=0, upper=100)
    df['D'] = df['D'].clip(lower=0, upper=100)
    return df[['date', 'K', 'D']]

def update_stock_with_kd(stock_code, df):
    operations = []
    for index, row in df.iterrows():
        k_value = row['K']
        d_value = row['D']
        if pd.isna(k_value):
            k_value = 0
        else:
            k_value = round(k_value, 2)
        if pd.isna(d_value):
            d_value = 0
        else:
            d_value = round(d_value, 2)
        operations.append(UpdateOne(
            {"code": stock_code, "date": row['date'].strftime('%Y-%m-%d')},
            {"$set": {
                "K": k_value,
                "D": d_value
            }},
            upsert=True
        ))
    if operations:
        collection.bulk_write(operations)

def process_all_stocks(batch_size=100):
    stock_codes = collection.distinct("code")
    for i in range(0, len(stock_codes), batch_size):
        batch = stock_codes[i:i + batch_size]
        for stock_code in batch:
            print(f"處理股票: {stock_code}")
            stock_data = get_stock_data(stock_code)
            if not stock_data.empty:
                kd_result = calculate_kd(stock_data)
                update_stock_with_kd(stock_code, kd_result)

process_all_stocks()
