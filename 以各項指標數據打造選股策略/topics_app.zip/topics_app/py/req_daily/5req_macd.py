from pymongo import MongoClient
import pandas as pd

client = MongoClient('mongodb://localhost:27017/')
db = client['test']
collection = db['price']

def get_stock_data(stock_code):
    cursor = collection.find({"code": stock_code}, {"_id": 0, "date": 1, "close": 1})
    data = list(cursor)
    df = pd.DataFrame(data)
    df['date'] = pd.to_datetime(df['date'], format='%Y-%m-%d')
    df = df.sort_values(by='date')
    df['close'] = df['close'].ffill()
    df['close'] = df['close'].fillna(0)
    return df

def calculate_macd(df):
    def calculate_ema(series, span):
        return series.ewm(span=span, adjust=False).mean()
    df['12_EMA'] = calculate_ema(df['close'], 12)
    df['26_EMA'] = calculate_ema(df['close'], 26)
    df['MACD'] = df['12_EMA'] - df['26_EMA']
    df['Signal'] = calculate_ema(df['MACD'], 9)
    df['MACD_Histogram'] = df['MACD'] - df['Signal']
    df['MACD'] = df['MACD'].round(2)
    df['Signal'] = df['Signal'].round(2)
    df['MACD_Histogram'] = df['MACD_Histogram'].round(2)
    return df[['date', 'MACD', 'Signal', 'MACD_Histogram']]

from pymongo import UpdateOne

def update_stock_with_macd(stock_code, df):
    operations = []
    for index, row in df.iterrows():
        operations.append(UpdateOne(
            {"code": stock_code, "date": row['date'].strftime('%Y-%m-%d')},
            {"$set": {
                "MACD": row['MACD'],
                "Signal": row['Signal'],
                "MACD_Histogram": row['MACD_Histogram']
            }},
            upsert=True
        ))
    if operations:
        collection.bulk_write(operations)

def process_all_stocks(batch_size=100):
    stock_codes = collection.distinct("code")
    for i in range(0, len(stock_codes), batch_size):
        batch = stock_codes[i:i + batch_size]
        for stock_code in batch:
            print(f"處理股票: {stock_code}")
            stock_data = get_stock_data(stock_code)
            if not stock_data.empty:
                macd_result = calculate_macd(stock_data)
                update_stock_with_macd(stock_code, macd_result)

process_all_stocks()
