import cv2

img = cv2.imread("output1.jpg")

# 轉換色彩空間
# img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

# 二值化
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
cv2.imwrite("output2.jpg", thresh)
cv2.imshow("two", thresh)
# 找到物體的輪廓
contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# 找到最大的轮廓
max_contour = max(contours, key=cv2.contourArea)

# 计算轮廓的重心
M = cv2.moments(max_contour)
center_x = int(M['m10'] / M['m00'])
center_y = int(M['m01'] / M['m00'])

# 在图像上绘制重心
cv2.circle(img, (center_x, center_y), 5, (0, 0, 255), -1)
# 計算物體的重心
# moments = cv2.moments(contours[0])
# cx = int(moments['m10'] / moments['m00'])
# cy = int(moments['m01'] / moments['m00'])

# 繪製重心
# cv2.circle(img, (cx, cy), 5, (0, 0, 255), -1)
cv2.imwrite("output3.jpg", img)

# 顯示結果
cv2.imshow("重心", img)

# 在图像上绘制红色直线
red_color = (0, 0, 255)  # 红色，格式为 (B, G, R)
thickness = 2  # 线条厚度

# 确定直线的起点和终点坐标
start_point = (center_x, center_y)
end_point = (center_x + 210, center_y)  # 在重心点的右侧延伸50个像素

# 绘制直线
image_with_line = cv2.line(img, start_point, end_point, red_color, thickness)

# 保存带有红线的图像
cv2.imwrite('image_with_line.jpg', image_with_line)
cv2.imshow("line", image_with_line)
cv2.waitKey(0)
cv2.destroyAllWindows()