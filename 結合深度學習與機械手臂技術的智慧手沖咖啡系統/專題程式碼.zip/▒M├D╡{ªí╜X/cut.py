import cv2
import numpy as np
# img = cv2.imread("coffee.jpg")

img = cv2.imread('coffee.jpg')
mask = np.zeros(img.shape[:2],np.uint8)
bgdModel = np.zeros((1,65),np.float64)
fgdModel = np.zeros((1,65),np.float64)
rect = (10,5,435,235)
cv2.grabCut(img,mask,rect,bgdModel,fgdModel,5,cv2.GC_INIT_WITH_RECT)
mask2 = np.where((mask==2)|(mask==0),0,1).astype('uint8')
out = img*mask2[:,:,np.newaxis]

# 轉換色彩空間
# img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

# 使用 GrabCut 算法進行分割
# bgdModel = np.zeros((1, 65), np.float64)
# fgdModel = np.zeros((1, 65), np.float64)

# mask = cv2.grabCut(img, None, gcInit=cv2.GC_INIT_WITH_RECT, bgdModel=bgdModel, fgdModel=fgdModel, iterCount=10)

# 將前景與背景分離
# out = cv2.bitwise_and(img, mask[:, :, 0] == cv2.GC_PR_FGD)

# 顯示結果
cv2.imwrite("output1.jpg", out)
cv2.imshow("前景", out)
cv2.waitKey(0)
cv2.destroyAllWindows()