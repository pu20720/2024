import os

# 資料夾路徑
folder_path = 'C:/Users/USER/PycharmProjects/YOLO7_1/yolov7/datasets/paperfin/images/train'

# 取得資料夾中所有圖片的檔案名稱
image_files = os.listdir(folder_path)

# 打開txt檔案並寫入圖片的路徑
with open('image_paths.txt', 'w') as f:
    for image_file in image_files:
        # 確保只寫入圖片檔案
        if image_file.endswith('.jpg') or image_file.endswith('.jpeg') or image_file.endswith('.png'):
            image_path = os.path.join(folder_path, image_file)
            f.write(image_path + '\n')