from flask import Flask, render_template, request, jsonify, send_file
from ultralytics import YOLO
import os
from PIL import Image, ImageDraw, ImageFont
from datetime import datetime  # 导入datetime模块
import base64
from io import BytesIO



app = Flask(__name__)

# YOLOv10模型加载
model = YOLO('yolov10x.pt')


# 上传文件保存路径
UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# 全局变量，记录今天的检测次数
detection_count = 0  # 初始化检测次数

#信心值
lowest_confidence =0.0


#預測
@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json  # 获取 JSON 数据
        img_data = data.get('image')  # 获取 base64 编码的图片，Base64 編碼是一種將二進制數據（例如影像或文件）轉換為純文字字串的方式
        if not img_data:
            return jsonify({'error': 'No image provided'}), 400

        # 将 base64 编码的图片转为 PIL 图像
        img_data = base64.b64decode(img_data.split(',')[1])
        img = Image.open(BytesIO(img_data))
        #假設 img_data 是二進制數據，BytesIO(img_data) 就將它轉換為一個內存中的“文件”，這樣可以像操作文件那樣進行讀取。
        #將 BytesIO(img_data) 作為參數傳遞給 Image.open()

        # 保存图片文件
        now = datetime.now()
        timestamp = now.strftime('%Y%m%d_%H%M%S')  # 格式化为 YYYYMMDD_HHMMSS
        img_path = os.path.join(UPLOAD_FOLDER, f'webcam_{timestamp}.png')
        img.save(img_path)

        # 模型预测
        results = model(img_path)
        draw = ImageDraw.Draw(img)

        try:
            font = ImageFont.truetype("arial.ttf", 20)
        except IOError:
            font = ImageFont.load_default()

        predictions = []
        for result in results:
            for box in result.boxes:
                    class_name = model.names[int(box.cls[0])]
                    confidence = float(box.conf[0])
                    bbox = box.xyxy[0].tolist()
                    draw.rectangle([bbox[0], bbox[1], bbox[2], bbox[3]], outline='red', width=3)
                    label = f"{class_name} ({confidence:.2f})"
                    text_bbox = draw.textbbox((0, 0), label, font=font)
                    text_width = text_bbox[2] - text_bbox[0]
                    text_height = text_bbox[3] - text_bbox[1]
                    text_location = (bbox[0], bbox[1] - text_height - 5)
                    draw.rectangle([text_location, (text_location[0] + text_width, text_location[1] + text_height)], fill='red')
                    draw.text(text_location, label, fill='white', font=font)
                    center_x = (bbox[0] + bbox[2]) / 2
                    center_y = (bbox[1] + bbox[3]) / 2
                    if(confidence > lowest_confidence):
                        predictions.append({
                            'class': class_name,
                            'confidence': confidence,
                            'bbox': bbox,
                            'center': [center_x, center_y]
                        })

        # 保存带有标注的图像
        output_img_path = os.path.join(UPLOAD_FOLDER, f'annotated_{timestamp}.png')
        img.save(output_img_path)

        return jsonify({'predictions': predictions, 'image_url': output_img_path})

    except Exception as e:
        return jsonify({'error': str(e)}), 500



#沒用的下載
@app.route('/download/<filename>', methods=['GET'])
def download_image(filename):
    path = os.path.join(UPLOAD_FOLDER, filename)
    return send_file(path, as_attachment=True)


@app.route('/check') #!!
def check():
    return render_template('check.html')

@app.route('/success') #!!
def success():
    return render_template('success.html')

@app.route('/inventory') #!!
def inventory():
    return render_template('inventory.html')

@app.route('/call') #!!
def call():
    return render_template('call.html')

@app.route('/') #!!
def home():
    return render_template('home.html')

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/buy_system') #!!
def buy_system():
    return render_template('buy_system.html')

@app.route('/sales') #!!
def sales():
    return render_template('sales.html')

@app.route('/peak') #!!
def peak():
    return render_template('peak.html')

@app.route('/revenue')
def revenue():
    return render_template('revenue.html')

if __name__ == '__main__':
    app.run(debug=True)
