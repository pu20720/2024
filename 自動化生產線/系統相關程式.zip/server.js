const http = require('http');
const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const path = require('path');
const cors = require('cors');

const app = express();

// 解析 JSON 請求
app.use(cors());
app.use(bodyParser.json());

// MySQL 連線設定
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',      // 替換成你的 MySQL 用戶名
    password: 'changeme',      // 替換成你的 MySQL 密碼
    database: 'orders' // 資料庫名稱，應與你提供的資料庫對應
});

db.connect((err) => {
    if (err) throw err;
    console.log('MySQL 連線成功');
});

app.post('/submit-order', (req, res) => {
    console.log('接收到的請求資料:', req.body);

    const { companyName, redCandyBox, blueCandyBox, pinkCandyBox } = req.body;
    console.log(`公司名稱: ${companyName}, 紅糖果盒數量: ${redCandyBox}, 藍糖果盒數量: ${blueCandyBox}, 粉紅糖果盒數量: ${pinkCandyBox}`);

    // 確認所有欄位都有數據
    if (!companyName || !redCandyBox || !blueCandyBox || !pinkCandyBox) {
        console.error('缺少欄位'); // 加入錯誤日誌
        return res.status(400).send('缺少欄位');
    }

    const sql = `INSERT INTO orders (company_name, red_candy_box, blue_candy_box, pink_candy_box) 
                 VALUES (?, ?, ?, ?)`;

    db.query(sql, [companyName, redCandyBox, blueCandyBox, pinkCandyBox], (err, result) => {
        if (err) {
            console.error('訂單儲存失敗:', err); // 具體顯示錯誤
            return res.status(500).send('訂單儲存失敗');
        }
        console.log('訂單已成功儲存到資料庫');
        res.status(200).send('訂單已成功提交');
    });
});

// 提供靜態資源
app.use(express.static(path.join(__dirname, 'public')));
app.use((req, res, next) => {
    console.log('Request URL:', req.url);
    next();
});

// 啟動 HTTP 伺服器
http.createServer(app).listen(8080, '', () => {
    console.log('HTTP 伺服器已啟動，監聽 8080 port');
});
