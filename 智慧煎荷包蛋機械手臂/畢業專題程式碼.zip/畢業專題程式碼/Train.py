# pip install ultralytics

import ultralytics
from ultralytics import YOLO
import multiprocessing                       # 多執行續套件

if __name__ == '__main__':
    multiprocessing.freeze_support()         # 避免多執行緒造成主程式重複執行

    # Build a YOLO model from pretrained weight
    model = YOLO('yolo11n.pt')

    # Display model information (optional)
    model.info()

    results = model.train(                              # Step 2 訓練YOLOv8
        data="datasets/data.yaml",                      # -指定訓練任務檔 *.yaml
        imgsz=640,                                      # -輸入影像大小
        epochs=200,                                     # -訓練世代數
        patience=0,                                     # -等待世代數, 若無改善就提前結束訓練
        batch=10,                                       # -批次大小
        project='FriedEgg Detect',                      # -專案名稱
        name='Train_00'                                 # -訓練實驗名稱
    )
