import ultralytics
ultralytics.checks()


from ultralytics import YOLO

model = YOLO('FriedEgg_Detect.pt')          # Step 1 載入預訓練模型

model.predict(                                         # Step 2 使用YOLO模型進行物件偵測
    source='datasets/test/images',                     # -指定待偵測影像子目錄
    conf=0.25,                                         # -偵測信心水準門限值
    save=True,                                         # -儲存偵測結果影像
    save_txt=True,                                     # -儲存偵測結果物件位置(YOLO格式)
    save_conf=False,                                   # -儲存物件偵測信心水準
    save_crop=False,                                   # -儲存擷取物件影像
    visualize=False                                    # -偵測過程特徵圖視覺化
)