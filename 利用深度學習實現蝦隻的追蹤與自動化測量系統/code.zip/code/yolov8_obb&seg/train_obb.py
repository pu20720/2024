from ultralytics import YOLO
import multiprocessing


if __name__ == '__main__':
    # multiprocessing.freeze_support()
    # Load a model
    model = YOLO(r'/home/lee/Work/Pycharmprojects/yolov8/ultralytics/yolov8n-obb.pt')  # load a pretrained model (recommended for training)
    result = model.train(
        data=r'/home/lee/Work/Pycharmprojects/yolov8/ultralytics/yaml/Mydata.yaml',
        imgsz=640,
        epochs=1000,
        patience=1000,
        batch=8,
        project='yolov8_test'
        #name='exp02'
    )
    # Train the model
    # results = model.train(data='dota8.yaml', epochs=100, imgsz=640)