import torch
import numpy as np
from sklearn.preprocessing import StandardScaler

# 定義模型結構（需要與訓練時使用的結構相同）
class ShrimpWeightPredictor(torch.nn.Module):
    def __init__(self):
        super(ShrimpWeightPredictor, self).__init__()
        self.fc1 = torch.nn.Linear(2, 10)
        self.fc2 = torch.nn.Linear(10, 1)
        
    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x.squeeze()

# 加載模型
model = ShrimpWeightPredictor()
model.load_state_dict(torch.load('/home/providence/rotate_yolov5_copy/results/shrimp_weight_model.pth'))
model.eval()

# 加載數據以獲取用於標準化的參數
data = np.loadtxt('/home/providence/rotate_yolov5_copy/len_wid_wei.txt')
X = data[:, :2]  # 長度和寬度
y = data[:, 2]   # 重量

scaler_X = StandardScaler()
scaler_y = StandardScaler()
scaler_X.fit(X)
scaler_y.fit(y.reshape(-1, 1))

# 測試函數
def predict_weight(length, width):
    # 將輸入數據標準化
    input_data = np.array([[length, width]])
    input_data_scaled = scaler_X.transform(input_data)
    
    # 轉換為PyTorch張量
    input_tensor = torch.FloatTensor(input_data_scaled)
    
    # 進行預測
    with torch.no_grad():
        prediction_scaled = model(input_tensor)
    
    # 反標準化預測結果
    prediction = scaler_y.inverse_transform(prediction_scaled.numpy().reshape(-1, 1))
    
    return prediction[0][0]

# 主循環
while True:
    try:
        length = float(input("請輸入蝦的長度 (cm)，或輸入 'q' 退出: "))
        width = float(input("請輸入蝦的寬度 (cm): "))
        
        predicted_weight = predict_weight(length, width)
        print(f"預測的魚重量為: {predicted_weight:.2f} g")
    except ValueError:
        print("程序結束。謝謝使用！")
        break