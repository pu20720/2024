import os
import cv2
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from PIL import Image
import torchvision.transforms as transforms

# 自定義數據集類別
class CustomDataset(Dataset):
    def __init__(self, image_dir, transform=None):
        self.image_dir = image_dir
        self.transform = transform
        self.image_files = [f for f in os.listdir(image_dir) if f.endswith('.jpg')]

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        image_file = self.image_files[idx]
        image_path = os.path.join(self.image_dir, image_file)
        image = Image.open(image_path).convert('L')  # 假設圖片是灰度圖像

        if self.transform:
            image = self.transform(image)

        return image, image_file

# 參數設定
test_image_dir = '/home/lee/Work/Pycharmprojects/yolov8/logistic_data/Test'
batch_size = 1

# 圖片轉換
transform = transforms.Compose([
    transforms.Resize((28, 28)),  # 假設圖片需要調整到28x28
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))
])

# 創建測試數據集和數據加載器
test_dataset = CustomDataset(image_dir=test_image_dir, transform=transform)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

# 加載訓練好的模型
class LogisticRegressionModel(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(LogisticRegressionModel, self).__init__()
        self.linear = nn.Linear(input_dim, output_dim)

    def forward(self, x):
        out = self.linear(x)
        return out

# 假設有10個類別，請根據你的實際類別數量設置
num_classes = 2  # 修改為實際的類別數
model = LogisticRegressionModel(input_dim=28*28, output_dim=num_classes)
model.load_state_dict(torch.load('./logistic_regression_model.pth'))
model.eval()

# 類別名稱映射（假設你有類別名稱）
class_names = ['blur', 'clear']  # 修改為你的類別名稱

result_dir = './result'

# 在測試集上進行預測
with torch.no_grad():
    for images, image_files in test_loader:
        images = images.view(-1, 28 * 28)
        outputs = model(images)
        _, predicted = torch.max(outputs.data, 1)
        predicted_class = class_names[predicted.item()]
        confidence = torch.softmax(outputs, dim=1)[0][predicted.item()].item()

        # 讀取原始圖片（用於畫圖）
        image_path = os.path.join(test_image_dir, image_files[0])
        image = cv2.imread(image_path)

        # 在圖片上畫出預測類別和置信度
        label = f'{predicted_class}: {confidence:.2f}'
        cv2.putText(image, label, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2, cv2.LINE_AA)

        # 將結果圖片保存到 result 文件夾
        result_path = os.path.join(result_dir, image_files[0])
        cv2.imwrite(result_path, image)
	
        print(f'Saved {result_path} with label {label}')
        #print(f'Image: {image_files[0]}, Predicted Class: {predicted_class}')
