import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from PIL import Image
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score

# 自定義數據集類別
class CustomDataset(Dataset):
    def __init__(self, image_dir, label_dir, transform=None):
        self.image_dir = image_dir
        self.label_dir = label_dir
        self.transform = transform
        self.image_files = [f for f in os.listdir(image_dir) if f.endswith('.jpg')]
        
        # 創建類別名稱到整數的映射
        self.classes = sorted(set([open(os.path.join(label_dir, f.replace('.jpg', '.txt'))).read().strip() 
                                   for f in self.image_files]))
        self.class_to_idx = {cls: idx for idx, cls in enumerate(self.classes)}

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        image_file = self.image_files[idx]
        image_path = os.path.join(self.image_dir, image_file)
        image = Image.open(image_path).convert('L')  # 假設圖片是灰度圖像

        label_file = image_file.replace('.jpg', '.txt')
        label_path = os.path.join(self.label_dir, label_file)
        with open(label_path, 'r') as f:
            label_str = f.read().strip()
            label = self.class_to_idx[label_str]

        if self.transform:
            image = self.transform(image)

        return image, label

# 參數設定
train_image_dir = '/home/lee/Work/Pycharmprojects/yolov8/logistic_data/train/images'
train_label_dir = '/home/lee/Work/Pycharmprojects/yolov8/logistic_data/train/labels'
val_image_dir = '/home/lee/Work/Pycharmprojects/yolov8/logistic_data/value/images'
val_label_dir = '/home/lee/Work/Pycharmprojects/yolov8/logistic_data/value/labels'
batch_size = 8
learning_rate = 0.0001
num_epochs = 500

# 圖片轉換
transform = transforms.Compose([
    transforms.Resize((28, 28)),
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))
])

# 創建訓練和驗證數據集和數據加載器
train_dataset = CustomDataset(image_dir=train_image_dir, label_dir=train_label_dir, transform=transform)
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)

val_dataset = CustomDataset(image_dir=val_image_dir, label_dir=val_label_dir, transform=transform)
val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

# 定義 Logistic Regression 模型
class LogisticRegressionModel(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(LogisticRegressionModel, self).__init__()
        self.linear = nn.Linear(input_dim, output_dim)

    def forward(self, x):
        out = self.linear(x)
        return out

input_dim = 28 * 28
output_dim = len(train_dataset.classes)

model = LogisticRegressionModel(input_dim, output_dim)

# 定義損失函數和優化器
criterion = nn.CrossEntropyLoss()
optimizer = optim.SGD(model.parameters(), lr=learning_rate)

# 添加一個用於計算指標的函數
def compute_metrics(y_true, y_pred):
    precision = precision_score(y_true, y_pred, average='weighted')
    recall = recall_score(y_true, y_pred, average='weighted')
    f1 = f1_score(y_true, y_pred, average='weighted')
    return precision, recall, f1

# 記錄指標
train_losses = []
val_losses = []
val_accs = []
precisions = []
recalls = []
f1_scores = []

# 訓練和驗證模型
best_val_acc = 0
best_metrics = {'precision': 0, 'recall': 0, 'f1': 0}

for epoch in range(num_epochs):
    # 訓練階段
    model.train()
    train_loss = 0
    for images, labels in train_loader:
        images = images.view(-1, 28 * 28)
        outputs = model(images)
        loss = criterion(outputs, labels)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        train_loss += loss.item()
    train_loss /= len(train_loader)
    train_losses.append(train_loss)

    # 驗證階段
    model.eval()
    with torch.no_grad():
        all_predictions = []
        all_labels = []
        correct = 0
        total = 0
        val_loss = 0
        for images, labels in val_loader:
            images = images.view(-1, 28 * 28)
            outputs = model(images)
            val_loss += criterion(outputs, labels).item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            all_predictions.extend(predicted.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

        val_loss /= len(val_loader)
        val_losses.append(val_loss)
        val_accuracy = 100 * correct / total
        val_accs.append(val_accuracy)
        
        # 計算指標
        precision, recall, f1 = compute_metrics(all_labels, all_predictions)
        precisions.append(precision)
        recalls.append(recall)
        f1_scores.append(f1)
        
        # 更新最佳性能
        if val_accuracy > best_val_acc:
            best_val_acc = val_accuracy
            best_metrics = {'precision': precision, 'recall': recall, 'f1': f1}
        
        # 打印當前 epoch 的性能
        print(f'Epoch [{epoch+1}/{num_epochs}]')
        print(f'Training Loss: {train_loss:.4f}, Validation Loss: {val_loss:.4f}')
        print(f'Validation Accuracy: {val_accuracy:.2f}%')
        print(f'Precision: {precision:.4f}, Recall: {recall:.4f}, F1 Score: {f1:.4f}')
        print('-' * 50)

# 訓練結束後打印最終性能和最佳性能
print('\nTraining completed!')
print('\nFinal Performance:')
print(f'Validation Accuracy: {val_accuracy:.2f}% (Best: {best_val_acc:.2f}%)')
print(f'Precision: {precision:.4f} (Best: {best_metrics["precision"]:.4f})')
print(f'Recall: {recall:.4f} (Best: {best_metrics["recall"]:.4f})')
print(f'F1 Score: {f1:.4f} (Best: {best_metrics["f1"]:.4f})')

# 打印混淆矩陣
cm = confusion_matrix(all_labels, all_predictions)
print('\nConfusion Matrix:')
print(cm)

# 儲存模型
torch.save(model.state_dict(), 'logistic_regression_model.pth')

# 畫出訓練和驗證曲線
epochs = range(1, num_epochs+1)
plt.figure(figsize=(15, 10))

plt.subplot(2, 2, 1)
plt.plot(epochs, train_losses, 'b', label='Training Loss')
plt.plot(epochs, val_losses, 'r', label='Validation Loss')
plt.title('Training and Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()

plt.subplot(2, 2, 2)
plt.plot(epochs, val_accs, 'g', label='Validation Accuracy')
plt.title('Validation Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy (%)')
plt.legend()

plt.subplot(2, 2, 3)
plt.plot(epochs, precisions, 'r', label='Precision')
plt.plot(epochs, recalls, 'g', label='Recall')
plt.plot(epochs, f1_scores, 'b', label='F1 Score')
plt.title('Precision, Recall, and F1 Score')
plt.xlabel('Epochs')
plt.ylabel('Score')
plt.legend()

plt.tight_layout()

# 保存圖像
plt.savefig('training_curves.png', dpi=300, bbox_inches='tight')
plt.close()

# 繪製混淆矩陣
plt.figure(figsize=(10, 8))
plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
plt.title('Confusion Matrix')
plt.colorbar()
tick_marks = np.arange(len(train_dataset.classes))
plt.xticks(tick_marks, train_dataset.classes, rotation=45)
plt.yticks(tick_marks, train_dataset.classes)
plt.xlabel('Predicted Label')
plt.ylabel('True Label')
plt.tight_layout()
plt.savefig('confusion_matrix.png', dpi=300, bbox_inches='tight')
plt.close()

print("Training completed. Model saved as 'logistic_regression_model.pth'")
print("Training curves saved as 'training_curves.png'")
print("Confusion matrix saved as 'confusion_matrix.png'")